export interface Clue {
  id: string;
  content: string;
  category: 'physical' | 'testimony' | 'alibi' | 'observation';
  importance: 'critical' | 'important' | 'minor';
}

// 问题类型标记
export type QuestionType = 'invalid' | 'misleading' | 'normal' | 'sequential-key' | 'hidden-key';

// 更新QuestionVariant接口
export interface QuestionVariant {
  id: string;
  text: string;
  type: QuestionType;
  contradictionId?: string;
  keywords?: string[];
  colomboFollowUp: string;
  hint: string;
  basePoints: number;
  responses: QuestionResponse[];
  // 带风格的回答（优先级高于responses）
  // 结构: [{ gentle: {...}, serious: {...}, probing: {...} }]
	  styledResponses?: {
	    gentle: QuestionResponse;
	    serious: QuestionResponse;
	    probing: QuestionResponse;
	  }[];
  // 顺序关键问题标记
  sequentialOrder?: number; // 1, 2, 3 表示必须按顺序回答
  // 无效/误导问题的特殊回答
  invalidResponse?: string;
  misleadingResult?: string;
}

export interface QuestionResponse {
  responses: string[];
  followUp: string;
  containsKeyInfo: boolean;
  keyInfo?: string;
}

export interface Stage {
  id: number;
  name: string;
  description: string;
  requiredQuestions: number;
  unlocksSequentialKey: boolean;
  sequentialOrder?: number; // 解锁第几个顺序关键问题
}

// 矛盾类型
export interface Contradiction {
  id: string;
  name: string;
  description: string;
  keywords: string[]; // 触发关键词
  hint: string; // 玩家需要思考的方向提示
  relatedClue: string; // 相关线索内容
  evidence: string; // 证据说明
}

export const contradictions: Contradiction[] = [
  {
    id: 'lake',
    name: '湖边行踪矛盾',
    description: '声称整晚在家睡觉，却被证人看见深夜在湖边使用碎木机',
    keywords: ['湖', '边', '湖边', '约尔拉湖', '碎木机', '证人', '看见', '目击', '深夜', '晚上'],
    hint: '证人说在湖边看到了他，但他声称整晚都在家...',
    relatedClue: '有证人看见他在案发深夜开着拖碎木机的车出现在湖边',
    evidence: '目击者清楚地看到了他的车和样貌',
  },
  {
    id: 'clean',
    name: '清理房屋矛盾',
    description: '妻子失踪后立刻清洗车库、换掉地毯，行为极度反常',
    keywords: ['车库', '清洗', '清理', '地毯', '刷', '刷墙', '装修', '换', '清洗'],
    hint: '他为什么要在这个时候装修？太巧了...',
    relatedClue: '海伦失踪后，他立刻刷了车库、换掉了所有地毯',
    evidence: '在妻子失踪当天进行大规模清理，极不寻常',
  },
  {
    id: 'evidence',
    name: '物证矛盾',
    description: '湖边积雪中找到海伦的人体组织，与碎木机血迹吻合',
    keywords: ['头发', '骨头', '牙齿', '血迹', '人体', '组织', '碎片', '鉴定', '匹配', '物证', '湖边'],
    hint: '湖边找到的物证和海伦完全匹配...',
    relatedClue: '湖边积雪中找到海伦的头发、骨头碎片、牙齿，还有碎木机残留的血迹',
    evidence: '经过鉴定，所有物证与海伦完全匹配',
  },
];

export interface GameProgress {
  score: number;
  errors: number;
  maxErrors: number;
  currentStage: number;
  currentSequentialIndex: number; // 当前应该回答的第几个关键问题 (1, 2, 3)
  answeredQuestions: Set<string>;
  questionsAsked: number; // 已询问的问题数量
  maxQuestions: number; // 最大可询问问题数
  discoveredContradictions: Set<string>; // 发现但未记录的矛盾
  recordedContradictions: Set<string>; // 已记录的矛盾（需要记录才能破案）
  conversationHistory: ConversationEntry[];
  clues: Clue[];
  topicResponses: Map<string, number>;
}

export interface ConversationEntry {
  speaker: 'colombo' | 'suspect' | 'system';
  text: string;
  isQuestion?: boolean;
  questionId?: string;
}

// 审问风格类型
export type InterrogationStyle = 'gentle' | 'serious' | 'probing';

// 带风格的回答
export interface StyledResponse {
  responses: string[];
  followUp: string;
  containsKeyInfo: boolean;
  keyInfo?: string;
}

// 带风格的问题回答
export interface StyledQuestionResponse {
  gentle: StyledResponse;
  serious: StyledResponse;
  probing: StyledResponse;
}

// 教程对话数据
export const tutorialDialogue: ConversationEntry[] = [
  { speaker: 'system', text: '【案情背景】空姐海伦突然失踪，活不见人、死不见尸。所有疑点都指向她的丈夫理查德——他有家暴史、妻子正准备离婚，他还连夜清洗车库、换掉地毯，行为极度反常。\n\n唯一嫌疑人：理查德（前CIA特工，反侦察能力极强，全程拒不认罪）\n\n核心谎言：他声称海伦是自己离家出走的，案发当晚他一直在家里睡觉，从没去过郊外湖边。' },
  { speaker: 'colombo', text: '（敲了敲门，慢悠悠走进理查德的客厅）理查德先生，您妻子海伦失踪多日，打扰您了。' },
  { speaker: 'suspect', text: '探长，请进。海伦的事我很遗憾，但她就是不想过了，自己走的。' },
  { speaker: 'colombo', text: '您最后一次见她是什么时候？' },
  { speaker: 'suspect', text: '那天晚上她跟我吵架，然后就摔门出去了。之后的事我真的不知道，我一直都在家里睡觉。' },
  { speaker: 'colombo', text: '哦，整晚都在家睡觉？' },
  { speaker: 'suspect', text: '是的，探长。我一整晚都在家，哪儿也没去。' },
  { speaker: 'colombo', text: '（掏出一张照片）那您能解释一下吗？有人在案发深夜，看见您开着车拖着碎木机，出现在郊外的约尔拉湖边。' },
  { speaker: 'suspect', text: '（脸色微变）不可能！我一整晚都在家，根本没出去过，更不知道什么碎木机。' },
  { speaker: 'colombo', text: '可那位证人，把您的车和样子看得很清楚。' },
  { speaker: 'suspect', text: '（镇定）那一定是看错了，这城市里有车的人多了去了。' },
  { speaker: 'colombo', text: '合理。那您为什么在妻子失踪后，立刻刷了车库、换掉了所有地毯？' },
  { speaker: 'suspect', text: '家里旧了，我正好想装修一下，这有什么问题吗？' },
  { speaker: 'colombo', text: '（笑了笑）偏偏在人失踪这天装修，未免太巧了。' },
  { speaker: 'suspect', text: '（沉默）...巧合而已。' },
];

// 游戏阶段类型
export type GamePhase = 'intro' | 'rules' | 'style-select' | 'tutorial' | 'investigation' | 'reveal' | 'success' | 'failure';

export const initialClues: Clue[] = [
  {
    id: 'clue-1',
    content: '海伦是空姐，理查德有家暴史',
    category: 'observation',
    importance: 'important',
  },
  {
    id: 'clue-2',
    content: '海伦正准备与理查德离婚',
    category: 'observation',
    importance: 'important',
  },
  {
    id: 'clue-3',
    content: '理查德是前CIA特工，反侦察能力强',
    category: 'observation',
    importance: 'important',
  },
  {
    id: 'clue-4',
    content: '案发后理查德清洗车库、换掉地毯',
    category: 'observation',
    importance: 'important',
  },
];

export const gameStages: Stage[] = [
  {
    id: 1,
    name: '开场寒暄',
    description: '先了解基本情况',
    requiredQuestions: 1,
    unlocksSequentialKey: true,
    sequentialOrder: 1,
  },
  {
    id: 2,
    name: '不在场证明',
    description: '调查他的行踪',
    requiredQuestions: 2,
    unlocksSequentialKey: true,
    sequentialOrder: 2,
  },
  {
    id: 3,
    name: '房屋清理',
    description: '追问房屋异常',
    requiredQuestions: 2,
    unlocksSequentialKey: true,
    sequentialOrder: 3,
  },
  {
    id: 4,
    name: '关键对峙',
    description: '准备好揭穿他',
    requiredQuestions: 3,
    unlocksSequentialKey: false,
  },
];

// ========== 无效问题（不会推进进度） ==========
const invalidQuestions: QuestionVariant[] = [
  {
    id: 'invalid-1',
    text: '您吃早餐了吗？',
    type: 'invalid',
    colomboFollowUp: '...',
    hint: '这似乎和案件无关',
    basePoints: 0,
    responses: [
      {
        responses: [
          '我一般早上喝杯咖啡就够了，不太吃早餐。',
          '您问这个做什么？和案子有关系吗？',
          '吃没吃早餐跟海伦失踪有什么关系？',
        ],
        followUp: '抱歉，只是随便问问。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'invalid-2',
    text: '您的狗叫什么名字？',
    type: 'invalid',
    colomboFollowUp: '...',
    hint: '这似乎和案件无关',
    basePoints: 0,
    responses: [
      {
        responses: [
          '我没有养狗，我对毛发过敏。',
          '这和案件有什么关系？',
          '我不太喜欢宠物。',
        ],
        followUp: '抱歉，打扰了。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'invalid-3',
    text: '您喜欢什么颜色的衣服？',
    type: 'invalid',
    colomboFollowUp: '...',
    hint: '这似乎和案件无关',
    basePoints: 0,
    responses: [
      {
        responses: [
          '我偏爱深色系，比较低调。您问这个做什么？',
          '衣服颜色和海伦失踪有什么关系？',
          '我穿什么颜色应该不影响案件的调查吧。',
        ],
        followUp: '抱歉，只是随便问问。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'invalid-4',
    text: '您最近看了什么电影？',
    type: 'invalid',
    colomboFollowUp: '...',
    hint: '这似乎和案件无关',
    basePoints: 0,
    responses: [
      {
        responses: [
          '最近太忙了，没什么时间看电影。',
          '这...和案子有关系吗？',
          '我不太关注娱乐新闻。',
        ],
        followUp: '抱歉，只是随便问问。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'invalid-5',
    text: '您对天气有什么看法？',
    type: 'invalid',
    colomboFollowUp: '...',
    hint: '这似乎和案件无关',
    basePoints: 0,
    responses: [
      {
        responses: [
          '最近的天气确实多变，但我不觉得这和案件有什么关系。',
          '天气？探长，您想问什么？',
          '天气怎么样和海伦失踪有什么关系吗？',
        ],
        followUp: '您说得对。',
        containsKeyInfo: false,
      },
    ],
  },
];

// ========== 误导性问题（会扣分） ==========
const misleadingQuestions: QuestionVariant[] = [
  {
    id: 'misleading-1',
    text: '海伦是不是有外遇？',
    type: 'misleading',
    colomboFollowUp: '这...我们没有证据表明...',
    hint: '这个问题偏离了主线',
    basePoints: -5,
    misleadingResult: '这与案件核心无关',
    responses: [
      {
        responses: [
          '我不知道她在外面有没有人，但她提出离婚，这让我很意外。',
          '外遇？我从没听说过。她就是个普通的空姐。',
          '（冷笑）您是在怀疑她有外遇？这太荒唐了。',
        ],
        followUp: '好吧，这与案件没有直接关系。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'misleading-2',
    text: '你们吵架时动过手吗？',
    type: 'misleading',
    colomboFollowUp: '家暴的事情我们会另外调查...',
    hint: '这个问题可能让嫌疑人警觉',
    basePoints: -5,
    misleadingResult: '没有直接证据',
    responses: [
      {
        responses: [
          '（神情紧张）我们是吵过架，但没有动手！我发誓！',
          '您这是什么意思？我是个守法公民。',
          '（回避）我们的婚姻是有问题，但没有您想的那种事。',
        ],
        followUp: '我们会核实这一点。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'misleading-3',
    text: '海伦的保险受益人是谁？',
    type: 'misleading',
    colomboFollowUp: '保险理赔是保险公司的事...',
    hint: '这个问题可能打草惊蛇',
    basePoints: -5,
    misleadingResult: '容易引起嫌疑人警觉',
    responses: [
      {
        responses: [
          '（皱眉）保险？我不太清楚受益人的事。',
          '您这是什么意思？您是在暗示我吗？',
          '海伦买过保险，但她自己才是受益人。这很正常。',
        ],
        followUp: '我们只是例行询问。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'misleading-4',
    text: '您的CIA背景对破案有帮助吗？',
    type: 'misleading',
    colomboFollowUp: '...',
    hint: '这与案件核心无关',
    basePoints: -3,
    misleadingResult: '没有直接线索',
    responses: [
      {
        responses: [
          '那是很多年前的事了，我现在只是个普通人。',
          'CIA经历和这个案子有什么关系？',
          '我离开CIA很久了，不想再提那段经历。',
        ],
        followUp: '好吧，我们继续。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'misleading-5',
    text: '你们家的财务状况如何？',
    type: 'misleading',
    colomboFollowUp: '财务问题我们会另外调查...',
    hint: '偏离核心矛盾',
    basePoints: -3,
    misleadingResult: '没有直接证据',
    responses: [
      {
        responses: [
          '我们的财务状况很正常，没有什么问题。',
          '您为什么要问这个？这和海伦失踪有什么关系？',
          '我只是普通收入，家庭财务一直很健康。',
        ],
        followUp: '明白了。',
        containsKeyInfo: false,
      },
    ],
  },
];

// ========== 顺序关键问题（必须按顺序回答）==========
const sequentialKeyQuestionsBase: QuestionVariant[] = [
  {
    id: 'seq-key-1',
    text: '案发当晚您真的一直在家，没去过湖边吗？',
    type: 'sequential-key',
    sequentialOrder: 1,
    contradictionId: 'lake',
    keywords: ['湖', '湖边', '约尔拉湖', '碎木机', '证人', '看见', '目击', '深夜', '晚上', '出去'],
    colomboFollowUp: '有证人说在湖边看到了您和您的车。',
    hint: '湖边行踪',
    basePoints: 15,
    responses: [
      {
        responses: [
          '不可能！我一整晚都在家，根本没出去过！',
          '湖边？什么湖边？我根本不知道您在说什么。',
          '（脸色微变）我...我说过了，我整晚都在睡觉，哪儿也没去。',
        ],
        followUp: '可证人说看到您开着车拖着碎木机出现在湖边。',
        containsKeyInfo: true,
        keyInfo: '否认去湖边，但被证人证词反驳',
      },
    ],
    // 带风格的回答
    styledResponses: [{
      gentle: {
        responses: [
          '探长，我理解您的怀疑，但我真的整晚都在家。可能是证人看错了，那天晚上开车的人应该不少。',
          '湖边...您是说约尔拉湖？探长，我那天晚上真的哪儿也没去。我理解有人可能看到了什么，但绝对不是我的车。',
          '（叹气）您们就是这样破案的？凭一个目击者的模糊证词就怀疑我？我那天晚上在家睡觉，这是事实。',
        ],
        followUp: '有证人说看到您开着车拖着碎木机出现在湖边，您的车和样子被看得很清楚。',
        containsKeyInfo: true,
        keyInfo: '湖边行踪被证人证词反驳',
      },
      serious: {
        responses: [
          '我警告您，探长！不要无端指控！我整晚都在家，这是铁一般的事实！',
          '（声音提高）湖边？！我从来没去过什么湖边！您有证据吗？没有证据就是诬陷！',
          '（冷笑）您是在钓鱼吗？用所谓的证人证词来套我话？我不会上当的。',
        ],
        followUp: '证人描述了您的车和您本人，包括您的外套颜色。这不是看错的问题。',
        containsKeyInfo: true,
        keyInfo: '面对证据时态度强硬但内心动摇',
      },
      probing: {
        responses: [
          '约尔拉湖...那天晚上？（停顿）探长，我只是个普通人，那天晚上我在家睡觉。证人可能看错了。',
          '您是说湖边的事？让我想想...（皱眉）那天晚上...我应该是在家的。等等，您为什么突然问这个？',
          '湖边？您是说那个有积雪的湖？（若有所思）我记得那天晚上确实下雪了...但我在家里，没去过湖边。',
        ],
        followUp: '证人看到的正是下雪的夜晚。您确定那天晚上您在家？',
        containsKeyInfo: true,
        keyInfo: '表现出对湖边话题的微妙反应',
      },
    }],
  },
  {
    id: 'seq-key-2',
    text: '您为什么在海伦失踪后立刻清洗车库、更换地毯？',
    type: 'sequential-key',
    sequentialOrder: 2,
    contradictionId: 'clean',
    keywords: ['车库', '清洗', '清理', '地毯', '刷', '刷墙', '装修', '换', '清洗'],
    colomboFollowUp: '这是巧合吗？',
    hint: '房屋清理',
    basePoints: 15,
    responses: [
      {
        responses: [
          '家里旧了，我正好想装修一下，这有什么问题吗？',
          '车库本来就脏了，刷一刷很正常。',
          '（回避）我只是顺便收拾一下，正好有时间。',
        ],
        followUp: '偏偏在人失踪这天装修，未免太巧了。',
        containsKeyInfo: true,
        keyInfo: '清理行为极度反常',
      },
    ],
    // 带风格的回答
    styledResponses: [{
      gentle: {
        responses: [
          '探长，您知道车库用了很多年了，地板上全是油污。趁这几天有空，我想着彻底打扫一下，正好天气也不错。',
          '装修房子这种事，随时都可以做不是吗？和海伦的事没有关系。',
          '（解释）您看，我家确实需要翻新了。我不是那种会隐藏什么的人，我只是想改善一下居住环境。',
        ],
        followUp: '可您选在妻子失踪的同一天开始装修，这时间点未免太巧合了。',
        containsKeyInfo: true,
        keyInfo: '解释合乎常理但时机可疑',
      },
      serious: {
        responses: [
          '我警告您！我在自己家里做什么是我的自由！您有什么权力过问我家的装修计划？！',
          '（声音颤抖）您到底想说什么？！我在自己家里打扫卫生也犯法吗？！',
          '装修是我早就计划好的！我有权利决定什么时候装修！（有些激动）您不要转移话题！',
        ],
        followUp: '您反应这么大，是心虚吗？',
        containsKeyInfo: true,
        keyInfo: '情绪激动，可能掩盖心虚',
      },
      probing: {
        responses: [
          '装修...（思考）探长，说实话，我之前确实没想过要装修。但那天晚上之后，我看着车库觉得...（停顿）...很乱，所以就想收拾一下。',
          '您是说...（若有所思）那天晚上之后，我确实觉得车库需要清理。您知道，有时候情绪会影响我们做决定。',
          '（若有所思）装修是我临时决定的。可能是因为那晚发生的事，让我突然想改变一些东西。什么东西？我也说不上来。',
        ],
        followUp: '那晚发生了什么事让您突然想清理车库？',
        containsKeyInfo: true,
        keyInfo: '透露出清理与失踪事件有关联',
      },
    }],
  },
  {
    id: 'seq-key-3',
    text: '湖边找到的人体碎片和血迹，您怎么解释？',
    type: 'sequential-key',
    sequentialOrder: 3,
    contradictionId: 'evidence',
    keywords: ['头发', '骨头', '牙齿', '血迹', '人体', '组织', '碎片', '鉴定', '匹配', '物证', '湖边'],
    colomboFollowUp: '经过鉴定，所有物证与海伦完全匹配。',
    hint: '物证',
    basePoints: 15,
    responses: [
      {
        responses: [
          '（震惊）什么人体碎片？！您在说什么？！',
          '这不可能！一定是搞错了！',
          '（沉默良久）...您在湖边找到了什么？',
        ],
        followUp: '头发、骨头碎片、牙齿，还有碎木机残留的血迹。经过鉴定，全部和海伦匹配。',
        containsKeyInfo: true,
        keyInfo: '面对物证无法否认',
      },
    ],
    // 带风格的回答
    styledResponses: [{
      gentle: {
        responses: [
          '（脸色苍白）探长，我...我需要知道您在说什么。您是说湖边发现了...人体组织？（声音颤抖）这太可怕了。',
          '物证...您是说DNA鉴定？（停顿良久）探长，我...（深吸一口气）我需要律师。',
          '（良久）您们找到了...海伦？（声音嘶哑）我...我不知道该怎么反应。我一直以为她只是离家出走了。',
        ],
        followUp: '是的，经过鉴定，所有物证与海伦完全匹配。您现在怎么解释？',
        containsKeyInfo: true,
        keyInfo: '面对真相无法再否认',
      },
      serious: {
        responses: [
          '（猛然站起）您是在陷害我！这些所谓的物证是谁提供的？！您有直接证据证明是我干的吗？！',
          '（冷笑）DNA匹配？那湖那么大，什么证据找不到！您们这是在钓鱼执法！',
          '（声音颤抖）您们...您们有证据证明是我做的吗？（崩溃）够了...够了...',
        ],
        followUp: '证据确凿：头发、骨头、牙齿、血迹全部与海伦匹配。碎木机上也有血迹。您现在可以承认了。',
        containsKeyInfo: true,
        keyInfo: '激烈反应后逐渐崩溃',
      },
      probing: {
        responses: [
          '（沉默很久）...所以您们找到她了。（低头）探长，您知道我是前CIA...我知道怎么掩盖痕迹。但您们还是找到了。',
          '（若有所思）湖边...约尔拉湖...（苦笑）我以为那里足够安全了。看来我低估了您们。',
          '（良久无言）...碎木机。（深吸一口气）探长，我需要坦白一些事情了。但首先，我想知道...您们是怎么找到我的？',
        ],
        followUp: '碎木机是您的，证人看到了您的车，物证与海伦完全匹配。理查德先生，您还要继续否认吗？',
        containsKeyInfo: true,
        keyInfo: '最终承认参与',
      },
    }],
  },
];

// 导出顺序关键问题（用于外部访问）
export const sequentialKeyQuestions: QuestionVariant[] = [
...sequentialKeyQuestionsBase,
];

// ========== 普通问题 ==========
const normalQuestionsBase: QuestionVariant[] = [
  {
    id: 'normal-1',
    text: '海伦是什么时候失踪的？',
    type: 'normal',
    keywords: ['失踪', '什么时候', '哪天', '时间', '最后'],
    colomboFollowUp: '让我核实一下日期。',
    hint: '失踪时间',
    basePoints: 5,
    responses: [
      {
        responses: [
          '就是上周五晚上，她跟我吵架之后就走了。',
          '大概...四五天前？具体的我记不太清了。',
          '上周五晚上，我们吵了一架，她就再也没有回来。',
        ],
        followUp: '谢谢，我会核对日期。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'normal-2',
    text: '你们为什么吵架？',
    type: 'normal',
    keywords: ['吵架', '原因', '为什么', '争吵'],
    colomboFollowUp: '了解婚姻状况有助于案件调查。',
    hint: '争吵原因',
    basePoints: 5,
    responses: [
      {
        responses: [
          '她觉得我不关心她，总是忙于工作。',
          '就是一些鸡毛蒜皮的小事积累起来的。',
          '她...她想离婚。我不同意。我们为此大吵了一架。',
        ],
        followUp: '离婚？（记下来）',
        containsKeyInfo: true,
        keyInfo: '海伦提出离婚',
      },
    ],
  },
  {
    id: 'normal-3',
    text: '您最后一次见到海伦是什么时候？',
    type: 'normal',
    keywords: ['最后', '见到', '看见', '什么时候', '见'],
    colomboFollowUp: '确认最后见面时间。',
    hint: '最后见面',
    basePoints: 5,
    responses: [
      {
        responses: [
          '就是那天晚上，她摔门出去的时候。',
          '周五晚上，我们吵架之后，她就离开了。',
          '那天晚上...她走之前，我们吵了一架。',
        ],
        followUp: '好的。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'normal-4',
    text: '海伦有没有留下什么话或者东西？',
    type: 'normal',
    keywords: ['留下', '东西', '话', '信息', '纸条', '留言'],
    colomboFollowUp: '了解失踪前的异常。',
    hint: '遗留物品',
    basePoints: 5,
    responses: [
      {
        responses: [
          '她只带走了自己的包和手机，什么话都没留。',
          '没有，她走得很突然，连招呼都没打。',
          '她...好像把一些证件带走了，但没给我留任何话。',
        ],
        followUp: '没留话就走了？',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'normal-5',
    text: '海伦有没有说过要去哪里？',
    type: 'normal',
    keywords: ['哪里', '去', '哪', '目的地', '计划'],
    colomboFollowUp: '调查失踪目的地。',
    hint: '去向',
    basePoints: 5,
    responses: [
      {
        responses: [
          '她说要回娘家，但我们联系过她娘家，她没去过。',
          '她没说要走，只是发脾气。',
          '她说她受够了这个家，然后就走了。我以为她只是说说而已。',
        ],
        followUp: '她娘家说她没去过？',
        containsKeyInfo: true,
        keyInfo: '海伦没去娘家',
      },
    ],
  },
  {
    id: 'normal-6',
    text: '您的车是什么颜色的？',
    type: 'normal',
    keywords: ['车', '颜色', '什么车', '品牌', '车型'],
    colomboFollowUp: '记录车辆信息。',
    hint: '车辆信息',
    basePoints: 3,
    responses: [
      {
        responses: [
          '深灰色的路虎揽胜。',
          '是一辆黑色的SUV。',
          '银灰色的，我开了有三年了。',
        ],
        followUp: '好的，我们会调查。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'normal-7',
    text: '海伦的朋友有没有联系过您？',
    type: 'normal',
    keywords: ['朋友', '联系', '海伦的朋友', '同事'],
    colomboFollowUp: '了解社交关系。',
    hint: '社交关系',
    basePoints: 3,
    responses: [
      {
        responses: [
          '她的朋友们都说没见过她。',
          '我们很久没联系她的朋友了。',
          '她们都在帮忙找她，但目前没有消息。',
        ],
        followUp: '好的，我们会继续调查。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'normal-8',
    text: '案发那天晚上天气如何？',
    type: 'normal',
    keywords: ['天气', '下雪', '雪', '晚上', '那天'],
    colomboFollowUp: '了解当晚天气情况。',
    hint: '天气状况',
    basePoints: 5,
    responses: [
      {
        responses: [
          '那天晚上下了大雪，路上都是积雪。',
          '天气很冷，下了一整夜的雪。',
          '我记得那天晚上雪很大，湖边应该积雪很厚。',
        ],
        followUp: '湖边？（记下来）',
        containsKeyInfo: true,
        keyInfo: '案发当晚下大雪',
      },
    ],
  },
  {
    id: 'normal-9',
    text: '您和海伦的婚姻持续多久了？',
    type: 'normal',
    keywords: ['婚姻', '多久', '结婚', '几年', '时间'],
    colomboFollowUp: '了解婚姻背景。',
    hint: '婚姻状况',
    basePoints: 3,
    responses: [
      {
        responses: [
          '我们结婚五年了。',
          '差不多五年了。',
          '五年前结的婚，但最近一年关系不太好。',
        ],
        followUp: '最近一年不太好？',
        containsKeyInfo: true,
        keyInfo: '婚姻出现问题',
      },
    ],
  },
  {
    id: 'normal-10',
    text: '海伦有没有留下任何线索？',
    type: 'normal',
    keywords: ['线索', '发现', '线索', '痕迹'],
    colomboFollowUp: '寻找失踪线索。',
    hint: '失踪线索',
    basePoints: 5,
    responses: [
      {
        responses: [
          '家里一切正常，没发现什么异常。',
          '我找遍了整个家，没发现任何线索。',
          '（回避）我没有仔细检查家里。',
        ],
        followUp: '没检查过家里？',
        containsKeyInfo: true,
        keyInfo: '没检查家里（可疑）',
      },
    ],
  },
  {
    id: 'normal-11',
    text: '海伦有没有提到过想离婚？',
    type: 'normal',
    keywords: ['离婚', '分居', '分开'],
    colomboFollowUp: '了解离婚意向。',
    hint: '离婚意愿',
    basePoints: 5,
    responses: [
      {
        responses: [
          '她提过，但我觉得那只是一时的气话。',
          '是的，她说受够了这段婚姻。',
          '她最近经常提离婚的事。',
        ],
        followUp: '她受够了这段婚姻？',
        containsKeyInfo: true,
        keyInfo: '海伦有离婚意愿',
      },
    ],
  },
  {
    id: 'normal-12',
    text: '您有没有找过私家侦探帮忙？',
    type: 'normal',
    keywords: ['私家侦探', '寻找', '调查'],
    colomboFollowUp: '了解调查进展。',
    hint: '调查方式',
    basePoints: 3,
    responses: [
      {
        responses: [
          '我没有找过，我相信警方能处理好。',
          '我试过联系一些调查机构，但没有结果。',
          '找侦探？为什么？我相信法律。',
        ],
        followUp: '好的。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'normal-13',
    text: '海伦的身份证件齐全吗？',
    type: 'normal',
    keywords: ['证件', '身份证', '护照', '执照'],
    colomboFollowUp: '了解证件情况。',
    hint: '身份文件',
    basePoints: 3,
    responses: [
      {
        responses: [
          '她带走了自己的包，证件应该在包里。',
          '护照和身份证她都带走了。',
          '她的证件齐全，但人却不见了。',
        ],
        followUp: '证件都带走了？',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'normal-14',
    text: '您有没有家暴史？',
    type: 'normal',
    keywords: ['家暴', '动手', '暴力', '打过'],
    colomboFollowUp: '记录家暴背景。',
    hint: '家庭暴力',
    basePoints: 10,
    responses: [
      {
        responses: [
          '（紧张）我们的婚姻是有问题，但我从来没有打过她！',
          '（回避）您为什么问这个？',
          '（沉默）...这是诬陷。',
        ],
        followUp: '（记下来）',
        containsKeyInfo: true,
        keyInfo: '有家暴嫌疑',
      },
    ],
    // 带风格的回答
    styledResponses: [{
      gentle: {
        responses: [
          '（神情紧张）探长，我理解您会问这种问题，但我们的婚姻...确实有问题，不过我从来没有对她动过手。',
          '您是说...（停顿）...我？（深吸一口气）探长，我和海伦之间确实有过争执，但我们是成年人，我们用言语解决问题。',
          '（回避您的目光）我不知道外面有什么传言，但我是清白的。我从来没有伤害过海伦。',
        ],
        followUp: '我们会调查这一点。',
        containsKeyInfo: true,
        keyInfo: '对家暴话题敏感',
      },
      serious: {
        responses: [
          '（猛然站起）您这是在诬陷我！我从来没有打过任何女人！您这是在侮辱我！',
          '（声音颤抖）您有什么证据？没有证据就是诽谤！我是前CIA特工，我会用法律手段维护我的名誉！',
          '（冷笑）有意思，您们警察就是这样办案的？用莫须有的罪名来逼供？',
        ],
        followUp: '冷静，我们只是例行询问。',
        containsKeyInfo: true,
        keyInfo: '反应过度，可能心虚',
      },
      probing: {
        responses: [
          '（沉默很久）...您问这个是什么意思？（回避）我和海伦之间的事，已经过去了。',
          '家暴...（若有所思）探长，我知道外面有很多传言。但您应该也知道，在这个行业里，有时候会有敌人散布谣言。',
          '（叹气）我们的婚姻确实有问题，但我发誓，我从来没有伤害过她。我...我可能说了些难听的话，但我没有动手。',
        ],
        followUp: '您说了些难听的话？',
        containsKeyInfo: true,
        keyInfo: '承认说过难听的话',
      },
    }],
  },
  {
    id: 'normal-15',
    text: '那晚有人能证明您在家吗？',
    type: 'hidden-key',
    colomboFollowUp: '了解一下。',
    hint: '不在场证明',
    basePoints: 15,
    responses: [
      {
        responses: [
          '我一个人在家，没有人能证明。',
          '我当时在睡觉，醒来就是早上了。',
          '我整晚都在家，这是我的家，我不需要向任何人证明。',
        ],
        followUp: '没有人证...',
        containsKeyInfo: true,
        keyInfo: '无法提供不在场证明',
      },
    ],
    // 带风格的回答
    styledResponses: [{
      gentle: {
        responses: [
          '一个人住，探长。',
          '我当时在睡觉，没有人能证明。但我真的在家。',
          '我的邻居可能会听到动静，但他们不会特别注意我的行踪。',
        ],
        followUp: '那您的邻居有没有听到什么异常？',
        containsKeyInfo: true,
        keyInfo: '暗示不在场证明薄弱',
      },
      serious: {
        responses: [
          '您是在暗示我没有不在场证明吗？我在自己家里睡觉需要什么证明？！',
          '（冷笑）您想找证人？好啊，去找！我一整晚都在睡觉，这就是我的不在场证明！',
          '我警告您！不要用这种方式套我话！',
        ],
        followUp: '（记下来）',
        containsKeyInfo: true,
        keyInfo: '面对质疑态度强硬',
      },
      probing: {
        responses: [
          '（若有所思）说起来，那天晚上确实很安静。我睡得很沉...（停顿）您问这个是什么意思？',
          '一个人在家...（沉默）探长，我理解您的怀疑，但我真的是一个人在家。',
          '那天晚上...我记得我关了所有的灯，然后在客厅看了会儿电视...（停顿）...之后就睡着了。',
        ],
        followUp: '您能描述一下那晚的具体情况吗？',
        containsKeyInfo: true,
        keyInfo: '细节模糊，可能在说谎',
      },
    }],
  },
];

// 导出普通问题（用于外部访问）
export const normalQuestions: QuestionVariant[] = [
  ...invalidQuestions,
  ...misleadingQuestions,
  ...normalQuestionsBase,
];

// 导出所有问题
export const questions: QuestionVariant[] = [
  ...normalQuestions,
];

// ========== 辅助函数 ==========

// 获取当前应该回答的顺序关键问题
export function getCurrentSequentialKeyQuestion(currentIndex: number): QuestionVariant | null {
  return sequentialKeyQuestionsBase.find(q => q.sequentialOrder === currentIndex) || null;
}

// 获取所有未解锁的顺序关键问题（用于显示"现在提出不合适"）
export function getFutureSequentialKeyQuestions(currentIndex: number): QuestionVariant[] {
  return sequentialKeyQuestionsBase.filter(q => (q.sequentialOrder ?? 0) > currentIndex);
}

// 检查是否是当前的顺序关键问题
export function isCurrentSequentialKeyQuestion(questionId: string, currentIndex: number): boolean {
  const question = sequentialKeyQuestionsBase.find(q => q.id === questionId);
  return (question?.sequentialOrder ?? -1) === currentIndex;
}

// 检查是否是未来的顺序关键问题
export function isFutureSequentialQuestion(questionId: string, currentIndex: number): boolean {
  const question = sequentialKeyQuestionsBase.find(q => q.id === questionId);
  return question ? (question.sequentialOrder ?? 0) > currentIndex : false;
}

// 检查问题关键词匹配
export function checkKeyQuestionMatch(input: string, keywords: string[]): { matched: boolean; score: number } {
  const lowerInput = input.toLowerCase();
  const matchedKeywords = keywords.filter(kw => lowerInput.includes(kw.toLowerCase()));
  
  if (matchedKeywords.length >= 2) {
    return { matched: true, score: 20 };
  } else if (matchedKeywords.length === 1) {
    return { matched: true, score: 10 };
  }

  return { matched: false, score: 0 };
}

// 获取嫌疑人回答
export function getSuspectResponse(
  question: QuestionVariant,
  responseCount: number
): { response: string; followUp: string; containsKey: boolean } {
  const responses = question.responses;
  const currentResponse = responses[responseCount % responses.length];

  return {
    response: currentResponse.responses[0],
    followUp: question.colomboFollowUp,
    containsKey: currentResponse.containsKeyInfo,
  };
}

// 根据审问风格获取嫌疑人回答
export function getStyledSuspectResponse(
  question: QuestionVariant,
  responseCount: number,
  style: InterrogationStyle
): { response: string; followUp: string; containsKey: boolean; attitude: string } {
  // 如果有带风格的回答，使用风格回答
  if (question.styledResponses) {
    const styledResp = question.styledResponses[0][style];
    const responses = styledResp.responses;
    const currentResponse = responses[responseCount % responses.length];
    
    // 态度描述
    const attitudes = {
      gentle: '嫌疑人态度平静，缓缓说道：',
      serious: '嫌疑人有些紧张，但仍强作镇定：',
      probing: '嫌疑人感到有些困惑，不确定您想说什么：'
    };
    
    return {
      response: currentResponse,
      followUp: styledResp.followUp,
      containsKey: styledResp.containsKeyInfo,
      attitude: attitudes[style]
    };
  }
  
  // 否则使用默认回答
  const defaultResp = getSuspectResponse(question, responseCount);
  const attitudes = {
    gentle: '嫌疑人态度平静，缓缓说道：',
    serious: '嫌疑人有些紧张，但仍强作镇定：',
    probing: '嫌疑人感到有些困惑：'
  };
  
  return {
    response: defaultResp.response,
    followUp: defaultResp.followUp,
    containsKey: defaultResp.containsKey,
    attitude: attitudes[style]
  };
}

// 获取可用的问题列表
export function getAvailableNormalQuestions(
  answeredQuestions: Set<string>,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _stageConfig?: Stage
): QuestionVariant[] {
  // 获取普通问题
  const availableNormal = normalQuestions.filter(q => {
    if (q.type === 'invalid' || q.type === 'misleading') return true;
    return !answeredQuestions.has(q.id);
  });

  // Fisher-Yates 洗牌算法打乱顺序
  return shuffleArray(availableNormal).slice(0, 8);
}

// 检查是否解锁顺序关键问题
export function isSequentialKeyUnlocked(stageId: number): boolean {
  const stageConfig = gameStages.find(s => s.id === stageId);
  return stageConfig?.unlocksSequentialKey ?? false;
}

// 获取当前阶段的顺序关键问题
export function getCurrentStageSequentialQuestion(stageId: number): QuestionVariant | null {
  const stageConfig = gameStages.find(s => s.id === stageId);
  if (!stageConfig?.sequentialOrder) return null;
  
  return sequentialKeyQuestionsBase.find(q => q.sequentialOrder === stageConfig.sequentialOrder) || null;
}

// 获取顺序关键问题的提示文本
export function getSequentialKeyHint(questionId: string): string {
  const question = sequentialKeyQuestionsBase.find(q => q.id === questionId);
  return question?.hint || '';
}

// Fisher-Yates 洗牌算法
function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
