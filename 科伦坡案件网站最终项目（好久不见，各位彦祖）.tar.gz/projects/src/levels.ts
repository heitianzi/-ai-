// 关卡数据结构
export interface Level {
  id: number;
  name: string;
  subtitle: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  maxQuestions: number;
  backgroundImage?: string;
  accentColor: string;
  suspectName: string;
  suspectRole: string;
}

// 关卡配置
export const levels: Level[] = [
  {
    id: 1,
    name: '第一关',
    subtitle: '雨夜画廊失窃案',
    description: '知名画家艾伦・索恩报案称名画《雾中港湾》失窃。暴雨夜、玻璃被砸、无指纹脚印...是流窜盗窃？还是自导自演骗保？',
    difficulty: 'easy',
    maxQuestions: 5,
    accentColor: 'from-blue-900 to-indigo-900',
    suspectName: '艾伦・索恩',
    suspectRole: '知名画家/画廊主人',
  },
  {
    id: 2,
    name: '第二关',
    subtitle: '碎木机抛尸案',
    description: '空姐海伦失踪，活不见人死不见尸。所有证据指向她的丈夫理查德...',
    difficulty: 'medium',
    maxQuestions: 4,
    accentColor: 'from-red-950 to-stone-900',
    suspectName: '理查德',
    suspectRole: 'CIA特工（嫌疑人）',
  },
];

// 获取当前关卡
export function getLevel(levelId: number): Level | undefined {
  return levels.find((l) => l.id === levelId);
}

// 获取关卡总数
export function getTotalLevels(): number {
  return levels.length;
}

// 获取难度显示文本
export function getDifficultyText(difficulty: 'easy' | 'medium' | 'hard'): string {
  switch (difficulty) {
    case 'easy':
      return '简单';
    case 'medium':
      return '中等';
    case 'hard':
      return '困难';
  }
}
