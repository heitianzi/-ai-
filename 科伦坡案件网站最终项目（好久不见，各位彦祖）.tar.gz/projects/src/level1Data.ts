// 第一关：雨夜画廊失窃案
import { Contradiction, Clue, QuestionVariant, ConversationEntry } from './caseData';

// 第一关的矛盾
export const level1Contradictions: Contradiction[] = [
  {
    id: 'time',
    name: '时间矛盾',
    description: '声称19-21点在餐厅用餐，但餐厅19:45已停电',
    keywords: ['停电', '断电', '餐厅', '时间', '几点'],
    hint: '他说19点到21点在餐厅用餐，但餐厅停电了...',
    relatedClue: '格兰德餐厅昨晚19:45停电20分钟，无人在餐厅待到21点',
    evidence: '餐厅停电期间声称在此用餐，时间矛盾',
  },
  {
    id: 'rain',
    name: '雨具矛盾',
    description: '暴雨夜声称全程在室外行走，却穿着完全干燥的外套',
    keywords: ['淋雨', '淋湿', '暴雨', '雨具', '伞', '湿', '干', '外套'],
    hint: '他说暴雨夜淋湿了，但外套干得一点水渍都没有...',
    relatedClue: '报案时穿的外套完全干燥，与暴雨夜行走矛盾',
    evidence: '暴雨夜外套完全干燥，与声称淋雨矛盾',
  },
  {
    id: 'dust',
    name: '现场痕迹矛盾',
    description: '声称未进入失窃现场，却在碎玻璃上留下专属画材粉尘',
    keywords: ['粉尘', '灰尘', '痕迹', '进入', '现场', '玻璃', '画材'],
    hint: '他说站在门外没进去，但碎玻璃内侧有他的粉尘...',
    relatedClue: '碎玻璃内侧找到专属画材粉尘，只有他的工作室才有',
    evidence: '未进入现场却在内部留下痕迹，矛盾',
  },
];

// 第一关的初始线索
export const level1Clues: Clue[] = [
  {
    id: 'clue-1',
    content: '知名当代画家艾伦・索恩，报案称名画《雾中港湾》失窃',
    category: 'observation',
    importance: 'important',
  },
  {
    id: 'clue-2',
    content: '案发当晚暴雨倾盆，画廊后门玻璃被砸',
    category: 'observation',
    importance: 'important',
  },
  {
    id: 'clue-3',
    content: '现场无指纹、无脚印，警方初步判定为流窜盗窃',
    category: 'physical',
    importance: 'critical',
  },
  {
    id: 'clue-4',
    content: '艾伦因债务危机急需资金，有伪造失窃骗保动机',
    category: 'testimony',
    importance: 'critical',
  },
  {
    id: 'clue-5',
    content: '格兰德餐厅昨晚19:45停电20分钟',
    category: 'observation',
    importance: 'important',
  },
];

// 第一关的问题和回答
export const level1Questions: QuestionVariant[] = [
  // 第一个顺序关键问题 - 关于时间
  {
    id: 'q1_time',
    text: '您几点到画廊的？',
    type: 'sequential-key',
    sequentialOrder: 1,
    contradictionId: 'time',
    keywords: ['几点', '时间', '到画廊', '餐厅'],
    colomboFollowUp: '那您从餐厅到画廊开车要多久？',
    hint: '需要先问这个问题，了解艾伦的行踪',
    basePoints: 10,
    responses: [
      {
        responses: ['19点到21点我都在格兰德餐厅，吃完开车回来，21点10分站在画廊门口。'],
        followUp: '哦，格兰德餐厅。那您一个人用餐的吗？',
        containsKeyInfo: true,
        keyInfo: '19-21点在餐厅用餐',
      },
    ],
  },
  // 第二个顺序关键问题 - 关于雨具
  {
    id: 'q2_rain',
    text: '暴雨夜有没有淋湿？',
    type: 'sequential-key',
    sequentialOrder: 2,
    contradictionId: 'rain',
    keywords: ['淋湿', '淋雨', '暴雨', '雨'],
    colomboFollowUp: '那您从餐厅走到车上，肯定淋湿了吧？',
    hint: '这个问题会揭示雨具矛盾',
    basePoints: 10,
    responses: [
      {
        responses: ['我带了大号雨伞，全程没淋到。'],
        followUp: '原来如此。您报案时穿的外套挂在那边，干得一点水渍都没有。',
        containsKeyInfo: true,
        keyInfo: '带了雨伞全程没淋到',
      },
    ],
  },
  // 第三个顺序关键问题 - 关于现场痕迹
  {
    id: 'q3_trace',
    text: '有没有进过现场？',
    type: 'sequential-key',
    sequentialOrder: 3,
    contradictionId: 'dust',
    keywords: ['进入', '现场', '玻璃', '画框'],
    colomboFollowUp: '您站在门口没进去？',
    hint: '这个问题会揭示粉尘矛盾',
    basePoints: 10,
    responses: [
      {
        responses: ['当然没有，我懂保护现场，站在门口没进去，直接报警。'],
        followUp: '可我们在碎玻璃内侧，找到了您鞋上的画材粉尘。',
        containsKeyInfo: true,
        keyInfo: '站在门外没进去',
      },
    ],
  },
  // 普通问题
  {
    id: 'q4_work',
    text: '案发当晚您在做什么？',
    type: 'normal',
    keywords: ['做什么', '工作', '案发'],
    colomboFollowUp: '好的，我了解一下。',
    hint: '普通问题，收集信息',
    basePoints: 5,
    responses: [
      {
        responses: ['正常下班后去餐厅吃饭，然后就发现画被偷了。'],
        followUp: '那您发现时是什么情况？',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'q5_electricity',
    text: '停电的时候您在哪？',
    type: 'normal',
    keywords: ['停电', '断电', '位置'],
    colomboFollowUp: '我明白了。',
    hint: '普通问题，了解行踪',
    basePoints: 5,
    responses: [
      {
        responses: ['我在餐厅吃饭，断电的时候也在。'],
        followUp: '那餐厅停电了您怎么吃饭的？',
        containsKeyInfo: true,
        keyInfo: '停电时在餐厅',
      },
    ],
  },
  {
    id: 'q6_alibi',
    text: '您有证人可以证明吗？',
    type: 'normal',
    keywords: ['证人', '证明', '不在场'],
    colomboFollowUp: '好的，我会去核实。',
    hint: '普通问题，收集信息',
    basePoints: 5,
    responses: [
      {
        responses: ['餐厅服务员应该记得我。'],
        followUp: '服务员说没人在餐厅待到21点。',
        containsKeyInfo: false,
      },
    ],
  },
  {
    id: 'q7_access',
    text: '谁有画廊的钥匙？',
    type: 'normal',
    keywords: ['钥匙', '进入', '权限'],
    colomboFollowUp: '我知道了。',
    hint: '普通问题，了解情况',
    basePoints: 5,
    responses: [
      {
        responses: ['只有我和几个核心员工有钥匙。'],
        followUp: '那您的钥匙有丢失过吗？',
        containsKeyInfo: false,
      },
    ],
  },
  // 关键问题
  {
    id: 'q8_key',
    text: '餐厅停电了您怎么吃饭的？',
    type: 'hidden-key',
    keywords: ['停电', '餐厅', '怎么', '吃饭'],
    colomboFollowUp: '哦？您记错餐厅了？',
    hint: '这个问题会揭示矛盾',
    basePoints: 15,
    responses: [
      {
        responses: ['我…… 我是去的分店！对，分店！'],
        followUp: '巧了，两家分店昨晚都在正常营业，没有您的消费记录。',
        containsKeyInfo: true,
        keyInfo: '声称去了分店',
      },
    ],
  },
];

// 第一关的教程对话
export const level1TutorialDialogue: ConversationEntry[] = [
  { speaker: 'system', text: '【案情背景】知名画家艾伦・索恩报案称画廊内价值80万美元的代表作《雾中港湾》失窃。案发当晚暴雨倾盆，画廊后门玻璃被砸，现场无指纹、无脚印...\n\n嫌疑人：艾伦・索恩（报案人，因债务危机有骗保动机）\n核心谎言：声称19-21点在格兰德餐厅用餐，21:10才发现失窃（实际19:30已回到画廊，自导自演伪造盗窃现场）' },
  { speaker: 'colombo', text: '（擦着眼镜，慢悠悠走到艾伦面前）索恩先生，麻烦您再说说，您昨晚是几点离开餐厅，几点到画廊的？' },
  { speaker: 'suspect', text: '我都说了三遍了，探长。19点到21点我都在格兰德餐厅，吃完开车回来，21点10分站在画廊门口，看见门被砸了。' },
  { speaker: 'colombo', text: '哦对，您说昨晚下那么大暴雨，您从餐厅走到车上，肯定淋湿了吧？我看您报案时穿的外套，挂在那边，干得一点水渍都没有。' },
  { speaker: 'suspect', text: '我…… 我带了大号雨伞，全程没淋到。' },
  { speaker: 'colombo', text: '原来如此，是我疏忽了。' },
  { speaker: 'colombo', text: '您看这后门，玻璃碎了一地，您说您21点10分发现失窃，第一时间没碰现场吧？' },
  { speaker: 'suspect', text: '当然没有，我懂保护现场，站在门口没进去，直接报警。' },
  { speaker: 'colombo', text: '可我们在碎玻璃内侧，找到了您鞋上的专用画材粉尘 —— 您上周调新颜料，这粉尘只有您工作室有。' },
  { speaker: 'suspect', text: '（脸色微变）可能是我之前开门时蹭上的！我白天来过画廊！' },
  { speaker: 'colombo', text: '合理，太合理了。画家嘛，天天待在这儿，正常。' },
  { speaker: 'colombo', text: '对了索恩先生，格兰德餐厅昨晚19:45就停电了，整个街区断电20分钟，服务员说没人在餐厅待到21点。您说您19-21点都在吃饭，是记错餐厅了？' },
  { speaker: 'suspect', text: '（慌乱）我…… 我是去的分店！对，分店！' },
  { speaker: 'colombo', text: '巧了，两家分店昨晚都在正常营业，没有您的消费记录，也没人见过您。' },
  { speaker: 'colombo', text: '（收起笔记本，轻声说）其实您根本没去餐厅，19点半就回画廊了。您砸后门、藏画作，想骗保还债，对不对？' },
  { speaker: 'suspect', text: '（沉默几秒，颓然低头）…… 是。' },
];
