// 背景音乐与音效管理器

class AudioManager {
  private bgmAudio: HTMLAudioElement | null = null;
  private isMuted: boolean = false;
  private volume: number = 0.3;

  constructor() {
    this.initBGM();
  }

  private initBGM() {
    // 悬疑氛围背景音乐 - 使用免费音乐资源
    const bgmSources = [
      'https://www.soundjay.com/ambient/sounds/dark-ambience-1.mp3',
      'https://assets.mixkit.co/music/preview/mixkit-spooky-fog-sounds-ambience-2.mp3'
    ];

    this.bgmAudio = new Audio();
    this.bgmAudio.loop = true; // 循环播放
    this.bgmAudio.volume = this.volume;

    // 使用第一个可用源
    this.bgmAudio.src = bgmSources[0];
    this.bgmAudio.preload = 'auto';
  }

  playBGM() {
    if (this.bgmAudio && !this.isMuted) {
      this.bgmAudio.play().catch(() => {
        // 自动播放被阻止，等待用户交互
      });
    }
  }

  pauseBGM() {
    if (this.bgmAudio) {
      this.bgmAudio.pause();
    }
  }

  toggleBGM() {
    this.isMuted = !this.isMuted;
    if (this.bgmAudio) {
      if (this.isMuted) {
        this.bgmAudio.pause();
      } else {
        this.bgmAudio.play().catch(() => {});
      }
    }
    return !this.isMuted;
  }

  setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.bgmAudio && !this.isMuted) {
      this.bgmAudio.volume = this.volume;
    }
  }

  getIsMuted(): boolean {
    return this.isMuted;
  }

  // 播放打字机音效
  playTypingSound() {
    const typingAudio = new Audio();
    typingAudio.volume = 0.1;
    // 轻微的敲击声
    typingAudio.src = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=';
    typingAudio.play().catch(() => {});
  }

  // 播放发现线索音效
  playClueFoundSound() {
    const clueAudio = new Audio();
    clueAudio.volume = 0.3;
    // 简单的提示音
    clueAudio.src = 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgA';
    clueAudio.play().catch(() => {});
  }

  // 播放通关成功音效
  playVictorySound() {
    const victoryAudio = new Audio();
    victoryAudio.volume = 0.4;
    victoryAudio.src = 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgA';
    victoryAudio.play().catch(() => {});
  }
}

export const audioManager = new AudioManager();
