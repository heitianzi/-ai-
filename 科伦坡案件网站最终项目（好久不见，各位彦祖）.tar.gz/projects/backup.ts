export interface Clue {
  id: string;
  content: string;
  category: 'physical' | 'testimony' | 'alibi' | 'observation';
  importance: 'critical' | 'important' | 'minor';
}

// 问题类型标记
export type QuestionType = 'invalid' | 'misleading' | 'normal' | 'sequential-key' | 'hidden-key';

// 更新QuestionVariant接口
export interface QuestionVariant {
  id: string;
  text: string;
  type: QuestionType;
  contradictionId?: string;
  keywords?: string[];
  colomboFollowUp: string;
  hint: string;
  basePoints: number;
  responses: QuestionResponse[];
  // 带风格的回答（优先级高于responses）
  // 结构: [{ gentle: {...}, serious: {...}, probing: {...} }]
	  styledResponses?: {
	    gentle: QuestionResponse;
	    serious: QuestionResponse;
	    probing: QuestionResponse;
	  };
  // 顺序关键问题标记
  sequentialOrder?: number; // 1, 2, 3 表示必须按顺序回答
  // 无效/误导问题的特殊回答
  invalidResponse?: string;
  misleadingResult?: string;
}

export interface QuestionResponse {
  responses: string[];
  followUp: string;
  containsKeyInfo: boolean;
  keyInfo?: string;
}

export interface Stage {
  id: number;
  name: string;
  description: string;
  requiredQuestions: number;
  unlocksSequentialKey: boolean;
  sequentialOrder?: number; // 解锁第几个顺序关键问题
}

// 矛盾类型
export interface Contradiction {
  id: string;
  name: string;
  description: string;
  keywords: string[]; // 触发关键词
  hint: string; // 玩家需要思考的方向提示
  relatedClue: string; // 相关线索内容
  evidence: string; // 证据说明
}

export const contradictions: Contradiction[] = [
  {
    id: 'contra-1',
    name: '暴雨淋雨矛盾',
    description: '暴雨夜未撑伞，外套却完全干燥，与"全程在室外行走"矛盾',
    keywords: ['雨', '淋', '湿', '伞', '暴雨', '外套', '衣服', '干燥', '干'],
    hint: '他说暴雨夜全程在室外，但他的外套却是干燥的...',
    relatedClue: '案发当晚暴雨倾盆，但艾伦的外套完全干燥',
    evidence: '报案时穿的外套挂在那边，干得一点水渍都没有',
  },
  {
    id: 'contra-2',
    name: '画材粉尘矛盾',
    description: '声称未进入失窃现场，却在碎玻璃上留下专属画材粉尘',
    keywords: ['粉', '尘', '画', '现场', '玻璃', '碎', '画材', '颜料', '画室'],
    hint: '他在碎玻璃上留下了画材粉尘，但他说没有进入现场...',
    relatedClue: '碎玻璃内侧找到了鞋上的专用画材粉尘',
    evidence: '上周调新颜料产生的粉尘，只有他的画室有',
  },
  {
    id: 'contra-3',
    name: '餐厅停电矛盾',
    description: '声称19-21点在餐厅用餐，而该餐厅当晚19:45已停电',
    keywords: ['电', '停电', '格兰德', '餐厅', '黑', '吃饭', '用餐', '晚餐', '分店', '停电'],
    hint: '格兰德餐厅19:45就停电了，他真的在那里吃饭了吗...',
    relatedClue: '格兰德餐厅当晚19:45已停电20分钟，无消费记录',
    evidence: '服务员说没人在餐厅待到21点，也没人见过他',
  },
];

export interface GameProgress {
  score: number;
  errors: number;
  maxErrors: number;
  currentStage: number;
  currentSequentialIndex: number; // 当前应该回答的第几个关键问题 (1, 2, 3)
  answeredQuestions: Set<string>;
  discoveredContradictions: Set<string>; // 发现但未记录的矛盾
  recordedContradictions: Set<string>; // 已记录的矛盾（需要记录才能破案）
  conversationHistory: ConversationEntry[];
  clues: Clue[];
  topicResponses: Map<string, number>;
}

export interface ConversationEntry {
  speaker: 'colombo' | 'suspect' | 'system';
  text: string;
  isQuestion?: boolean;
  questionId?: string;
}

// 审问风格类型
export type InterrogationStyle = 'gentle' | 'serious' | 'probing';

// 带风格的回答
export interface StyledResponse {
  responses: string[];
  followUp: string;
  containsKeyInfo: boolean;
  keyInfo?: string;
}

// 带风格的问题回答
export interface StyledQuestionResponse {
  gentle: StyledResponse;
  serious: StyledResponse;
  probing: StyledResponse;
}
