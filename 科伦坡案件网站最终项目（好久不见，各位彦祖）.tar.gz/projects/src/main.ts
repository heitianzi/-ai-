import './index.css';
import {
  type GameProgress,
  type QuestionVariant,
  type InterrogationStyle,
  initialClues,
  gameStages,
  questions,
  tutorialDialogue,
  getStyledSuspectResponse,
  getAvailableNormalQuestions,
  getCurrentSequentialKeyQuestion,
  sequentialKeyQuestions,
  checkKeyQuestionMatch,
} from './caseData';
import { levels, getLevel, getDifficultyText } from './levels';
import { audioManager } from './audio';

// ============ 类型定义 ============
type GamePhase =
  | 'intro'
  | 'level-select'
  | 'rules'
  | 'style-select'
  | 'tutorial'
  | 'investigation'
  | 'reveal'
  | 'victory'
  | 'failure';

interface State {
  phase: GamePhase;
  progress: GameProgress;
  customQuestionMode: boolean;
  selectedQuestionId: string | null;
  stageAnsweredCount: number; // 当前阶段已回答的普通问题数
  tutorialIndex: number; // 当前教程对话索引
  currentStyle: InterrogationStyle; // 当前审问风格
  askedHiddenKeyQuestion: boolean; // 是否询问了隐藏的关键问题
  askedTimeQuestion: boolean; // 是否询问了时间问题
  askedRainQuestion: boolean; // 是否询问了雨具问题
  askedTraceQuestion: boolean; // 是否询问了痕迹问题
  currentLevelId: number; // 当前关卡ID
}

// ============ 全局状态 ============
const state: State = {
  phase: 'intro',
  progress: {
    score: 100,
    errors: 0,
    maxErrors: 3,
    currentStage: 1,
    currentSequentialIndex: 1, // 当前应该回答第几个关键问题
    answeredQuestions: new Set(),
    questionsAsked: 0, // 已询问的问题数量
    maxQuestions: 4, // 最大可询问问题数
    discoveredContradictions: new Set(), // 发现但未记录的线索
    recordedContradictions: new Set<string>(), // 已记录的线索
    conversationHistory: [],
    clues: [...initialClues],
    topicResponses: new Map(),
  },
  customQuestionMode: false,
  selectedQuestionId: null,
  stageAnsweredCount: 0,
  currentStyle: 'gentle', // 默认温和风格
  tutorialIndex: 0, // 教程对话索引
  askedHiddenKeyQuestion: false, // 是否询问了隐藏的关键问题
  askedTimeQuestion: false, // 是否询问了时间问题
  askedRainQuestion: false, // 是否询问了雨具问题
  askedTraceQuestion: false, // 是否询问了痕迹问题
  currentLevelId: 1, // 默认第一关
};

// ============ 工具函数 ============
function $(selector: string): HTMLElement | null {
  return document.querySelector(selector);
}

function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

// ============ 渲染函数 ============
function renderApp(): void {
  const app = $('#app');
  if (!app) return;

  switch (state.phase) {
    case 'intro':
      app.innerHTML = renderIntro();
      break;
    case 'level-select':
      app.innerHTML = renderLevelSelect();
      break;
    case 'rules':
      app.innerHTML = renderRules();
      break;
    case 'investigation':
      app.innerHTML = renderInvestigation();
      break;
    case 'reveal':
      app.innerHTML = renderReveal();
      break;
    case 'style-select':
      app.innerHTML = renderStyleSelect();
      break;
    case 'tutorial':
      app.innerHTML = renderTutorial();
      break;
    case 'victory':
      app.innerHTML = renderVictory();
      break;
    case 'failure':
      app.innerHTML = renderFailure();
      break;
  }

  attachEventListeners();

  // 渲染后自动滚动对话到底部
  if (state.phase === 'investigation' || state.phase === 'tutorial') {
    requestAnimationFrame(() => {
      const container = document.getElementById('conversation-history');
      if (container) {
        container.scrollTop = container.scrollHeight;
      }
    });
  }
}

// ============ 关卡选择页面 ============
function renderLevelSelect(): string {
  return `
    <div class="min-h-screen bg-cover bg-center bg-no-repeat flex items-center justify-center p-4" style="background-image: url('/bg-detective.png'); background-color: rgba(20, 20, 20, 0.85); background-blend-mode: overlay;">
      <div class="max-w-4xl w-full">
        <div class="text-center mb-12">
          <h1 class="text-4xl md:text-5xl font-serif font-bold text-amber-100 mb-4" style="text-shadow: 2px 2px 8px rgba(0,0,0,0.8);">
            选择关卡
          </h1>
          <p class="text-amber-200/80 text-lg">选择一个案件开始您的调查</p>
        </div>
        
        <div class="grid md:grid-cols-2 gap-6">
          ${levels.map((level) => {
            const difficultyColor = level.difficulty === 'easy' ? 'text-green-400' : level.difficulty === 'medium' ? 'text-yellow-400' : 'text-red-400';
            const isLocked = level.id > 2; // 目前只解锁前两关
            
            return `
              <div class="bg-steine-paper/90 backdrop-blur-sm rounded-lg p-6 border-2 border-amber-900/50 shadow-xl ${isLocked ? 'opacity-60' : ''}">
                <div class="flex items-center justify-between mb-4">
                  <span class="text-2xl font-serif font-bold text-amber-900">${level.name}</span>
                  <span class="px-3 py-1 rounded-full text-sm font-medium ${difficultyColor} bg-black/30">
                    ${getDifficultyText(level.difficulty)}
                  </span>
                </div>
                
                <h3 class="text-xl font-bold text-gray-800 mb-3">${level.subtitle}</h3>
                
                <p class="text-gray-600 mb-4 text-sm leading-relaxed">
                  ${level.description}
                </p>
                
                <div class="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <span>最大问题数: ${level.maxQuestions}</span>
                  <span>嫌疑人: ${level.suspectName}</span>
                </div>
                
                ${isLocked ? `
                  <div class="text-center py-3 bg-gray-200 rounded-lg text-gray-500">
                    🔒 暂未解锁
                  </div>
                ` : `
                  <button 
                    onclick="selectLevel(${level.id})"
                    class="w-full py-3 bg-gradient-to-r from-amber-800 to-amber-900 hover:from-amber-700 hover:to-amber-800 text-amber-100 font-medium rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                  >
                    ${level.id === 2 ? '继续游戏' : '开始游戏'}
                  </button>
                `}
              </div>
            `;
          }).join('')}
        </div>
        
        <div class="text-center mt-8">
          <p class="text-amber-200/60 text-sm">完成案件可解锁下一关</p>
        </div>
      </div>
    </div>
  `;
}

// 全局函数：选择关卡
(window as unknown as Record<string, unknown>).selectLevel = (levelId: number) => {
  state.currentLevelId = levelId;
  const level = getLevel(levelId);
  if (level) {
    state.progress.maxQuestions = level.maxQuestions;
  }
  // 重置游戏状态
  resetGameState();
  state.phase = 'rules';
  renderApp();
};

function resetGameState() {
  state.progress = {
    score: 100,
    errors: 0,
    maxErrors: 3,
    currentStage: 1,
    currentSequentialIndex: 1,
    answeredQuestions: new Set(),
    questionsAsked: 0,
    maxQuestions: getLevel(state.currentLevelId)?.maxQuestions || 4,
    discoveredContradictions: new Set(),
    recordedContradictions: new Set(),
    conversationHistory: [],
    clues: [...initialClues],
    topicResponses: new Map(),
  };
  state.customQuestionMode = false;
  state.selectedQuestionId = null;
  state.stageAnsweredCount = 0;
  state.currentStyle = 'gentle';
  state.tutorialIndex = 0;
  state.askedHiddenKeyQuestion = false;
  state.askedTimeQuestion = false;
  state.askedRainQuestion = false;
  state.askedTraceQuestion = false;
}

function renderIntro(): string {
  return `
    <div class="min-h-screen bg-cover bg-center bg-no-repeat flex items-center justify-center p-4" style="background-image: url('/bg-detective.png'); background-color: rgba(20, 20, 20, 0.85); background-blend-mode: overlay;">
      <div class="max-w-2xl w-full text-center">
        <div class="mb-8">
          <div class="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center shadow-2xl border-4 border-gray-600">
            <span class="text-4xl">🔍</span>
          </div>
          <h1 class="text-4xl md:text-5xl font-serif font-bold text-black mb-2" style="text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">
            科伦坡探长
          </h1>
          <p class="text-xl text-gray-700 font-serif italic">
            侦探推理游戏
          </p>
        </div>
        <p class="text-lg text-gray-800/80 mb-8 leading-relaxed">
          扮演传奇侦探科伦坡，<br>
          通过提问发现嫌疑人陈述中的线索，<br>
          戳破一个又一个谎言。
        </p>
        <div class="space-y-4">
          <button id="select-level" class="w-full px-8 py-4 bg-gradient-to-r from-amber-700 to-amber-800 text-amber-100 rounded-lg text-lg font-serif shadow-lg hover:from-amber-600 hover:to-amber-700 transform hover:scale-105 transition-all duration-300 border-2 border-amber-600">
            选择关卡 🎯
          </button>
          <button id="start-game" class="w-full px-8 py-4 bg-gradient-to-r from-gray-700 to-gray-800 text-gray-50 rounded-lg text-lg font-serif shadow-lg hover:from-gray-800 hover:to-gray-900 transform hover:scale-105 transition-all duration-300 border-2 border-gray-600">
            快速开始（第二关） →
          </button>
        </div>
      </div>
    </div>
  `;
}

function renderRules(): string {
  return `
    <div class="min-h-screen bg-detective-bg flex items-center justify-center p-4">
      <div class="max-w-2xl w-full">
        <div class="bg-amber-50/80 rounded-xl p-8 shadow-xl border border-amber-200 light-panel">
          <h2 class="text-2xl font-serif font-bold text-amber-900 mb-6 text-center">
            📋 调查须知
          </h2>
          
          <div class="space-y-4 text-black mb-8">
            <div class="flex items-start gap-3">
              <span class="text-2xl">🎯</span>
              <div>
                <h3 class="font-bold mb-1">目标</h3>
                <p class="text-sm">通过提问发现嫌疑人陈述中的3个关键线索点，揭穿他的谎言。</p>
              </div>
            </div>
            
            <div class="flex items-start gap-3">
              <span class="text-2xl">⚡</span>
              <div>
                <h3 class="font-bold mb-1">机制</h3>
                <p class="text-sm">问题分阶段解锁，必须按顺序探索。选错关键问题会扣分并消耗机会。</p>
              </div>
            </div>
            
            <div class="flex items-start gap-3">
              <span class="text-2xl">💡</span>
              <div>
                <h3 class="font-bold mb-1 text-black">提示</h3>
                <p class="text-sm text-black">线索不足时，系统会给出调查方向提示。关键问题需要自己组织语言输入。</p>
              </div>
            </div>
            
            <div class="flex items-start gap-3">
              <span class="text-2xl">📝</span>
              <div>
                <h3 class="font-bold mb-1 text-black">记录</h3>
                <p class="text-sm text-black">你可以随时记录重要线索，帮助分析案情。</p>
              </div>
            </div>
          </div>
          
          <div class="border-t border-amber-300 pt-6">
            <h3 class="font-bold text-amber-900 mb-3">已知线索</h3>
            <div class="grid gap-2">
              ${state.progress.clues.map(clue => `
                <div class="flex items-center gap-2 text-sm text-black bg-amber-100/50 p-2 rounded">
                  <span class="w-2 h-2 rounded-full bg-amber-600"></span>
                  ${clue.content}
                </div>
              `).join('')}
            </div>
          </div>
          
          <button id="start-style-select" class="w-full mt-6 px-6 py-3 bg-gradient-to-r from-amber-700 to-amber-800 text-amber-50 rounded-lg font-serif shadow-lg hover:from-amber-800 hover:to-amber-900 transition-all duration-300">
            选择审问风格 →
          </button>
        </div>
      </div>
    </div>
  `;
}

function renderTutorial(): string {
  const currentIndex = state.tutorialIndex;
  const dialogue = tutorialDialogue[currentIndex];
  
  // 将对话添加到历史
  if (state.progress.conversationHistory.length <= currentIndex || 
      state.progress.conversationHistory[currentIndex]?.text !== dialogue?.text) {
    addConversation(dialogue.speaker, dialogue.text, false);
  }
  
  const isLastDialogue = currentIndex >= tutorialDialogue.length - 1;

  return `
    <div class="min-h-screen bg-detective-bg p-4 flex flex-col">
      <!-- 顶部标题和音乐控制 -->
      <div class="flex items-center justify-between mb-4">
        <h1 class="text-2xl font-serif font-bold text-red-800 flex-1 text-center">
          碎木机抛尸案 · 审讯实录
        </h1>
        <button id="toggle-bgm" onclick="toggleBGM()" class="p-2 hover:bg-amber-200 rounded-full transition-colors" title="背景音乐">
          <svg id="bgm-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M9 18V5l12-2v13"/>
            <circle cx="6" cy="18" r="3"/>
            <circle cx="18" cy="16" r="3"/>
          </svg>
        </button>
      </div>
      
      <!-- 对话区域 -->
      <div id="conversation-history" class="flex-1 overflow-y-auto mb-4 space-y-4 px-2" style="max-height: 60vh;">
        ${state.progress.conversationHistory.map(entry => {
          const bubbleClass = entry.speaker === 'colombo' ? 'colombo-bubble' : 
                             entry.speaker === 'suspect' ? 'suspect-bubble' : 'system-bubble';
          const nameClass = entry.speaker === 'colombo' ? 'font-bold text-amber-800' : 
                           entry.speaker === 'suspect' ? 'font-bold text-gray-700' : 'hidden';
          const name = entry.speaker === 'colombo' ? '科伦坡' : 
                       entry.speaker === 'suspect' ? '艾伦' : '';
          const isCurrent = entry.text === dialogue?.text;
          
          return `
            <div class="flex ${entry.speaker === 'colombo' ? 'justify-end' : entry.speaker === 'suspect' ? 'justify-start' : 'justify-center'} ${isCurrent ? 'animate-fade-in' : ''}">
              <div class="${bubbleClass} ${entry.speaker === 'system' ? 'max-w-full' : 'max-w-[85%]'}">
                ${entry.speaker !== 'system' ? `<div class="${nameClass} text-xs mb-1">${name}</div>` : ''}
                <div class="text-sm leading-relaxed whitespace-pre-wrap">${entry.text}</div>
              </div>
            </div>
          `;
        }).join('')}
      </div>
      
      <!-- 底部进度和按钮 -->
      <div class="bg-amber-100/80 rounded-lg p-4 shadow-lg">
        <div class="flex items-center justify-between mb-3">
          <div class="text-sm text-gray-700">
            对话进度: ${currentIndex + 1} / ${tutorialDialogue.length}
          </div>
          <div class="w-48 h-2 bg-gray-300 rounded-full overflow-hidden">
            <div class="h-full bg-amber-600 transition-all duration-300" 
                 style="width: ${((currentIndex + 1) / tutorialDialogue.length) * 100}%">
            </div>
          </div>
        </div>
        
        <button id="next-dialogue" 
                class="w-full px-6 py-3 bg-gradient-to-r from-amber-700 to-amber-800 text-white rounded-lg font-serif shadow-lg hover:from-amber-800 hover:to-amber-900 transition-all duration-300 flex items-center justify-center gap-2">
          ${isLastDialogue ? '开始调查 →' : '继续 →'}
        </button>
      </div>
    </div>
  `;
}

function renderStyleSelect(): string {
  return `
    <div class="min-h-screen bg-detective-bg flex items-center justify-center p-4">
      <div class="max-w-4xl w-full">
        <div class="bg-amber-50 rounded-lg p-8 shadow-xl border-4 border-amber-700">
          <h2 class="text-3xl font-serif font-bold text-center text-gray-900 mb-8">
            选择您的审问风格
          </h2>
          
          <div class="grid md:grid-cols-3 gap-6 mb-8">
            <!-- 温和套话 -->
            <button id="style-gentle" class="style-card p-6 rounded-lg border-4 border-gray-300 bg-white hover:border-amber-500 hover:shadow-lg transition-all duration-300 cursor-pointer">
              <div class="text-4xl mb-4 text-center">🤝</div>
              <h3 class="text-xl font-bold text-gray-900 text-center mb-2">温和套话</h3>
              <p class="text-sm text-gray-600 text-center mb-3">
                友善交谈，营造轻松氛围，让嫌疑人放松警惕
              </p>
              <ul class="text-xs text-gray-500 space-y-1">
                <li>• 嫌疑人态度配合</li>
                <li>• 不易露出破绽</li>
                <li>• 需要耐心引导</li>
              </ul>
            </button>
            
            <!-- 严肃施压 -->
            <button id="style-stern" class="style-card p-6 rounded-lg border-4 border-gray-300 bg-white hover:border-red-500 hover:shadow-lg transition-all duration-300 cursor-pointer">
              <div class="text-4xl mb-4 text-center">⚡</div>
              <h3 class="text-xl font-bold text-gray-900 text-center mb-2">严肃施压</h3>
              <p class="text-sm text-gray-600 text-center mb-3">
                严厉质问，制造心理压力，迫使嫌疑人露馅
              </p>
              <ul class="text-xs text-gray-500 space-y-1">
                <li>• 嫌疑人态度紧张</li>
                <li>• 可能露出破绽</li>
                <li>• 可能引起反感</li>
              </ul>
            </button>
            
            <!-- 旁敲侧击 -->
            <button id="style-indirect" class="style-card p-6 rounded-lg border-4 border-gray-300 bg-white hover:border-blue-500 hover:shadow-lg transition-all duration-300 cursor-pointer">
              <div class="text-4xl mb-4 text-center">🔍</div>
              <h3 class="text-xl font-bold text-gray-900 text-center mb-2">旁敲侧击</h3>
              <p class="text-sm text-gray-600 text-center mb-3">
                迂回试探，从侧面切入，让嫌疑人防不胜防
              </p>
              <ul class="text-xs text-gray-500 space-y-1">
                <li>• 绕过心理防线</li>
                <li>• 容易发现隐藏信息</li>
                <li>• 需要技巧和耐心</li>
              </ul>
            </button>
          </div>
          
          <p class="text-center text-gray-600 text-sm">
            选择后将根据此风格进行审讯，每种风格会影响嫌疑人的态度和线索发现方式
          </p>
        </div>
      </div>
    </div>
  `;
}

function renderInvestigation(): string {
  const { progress, customQuestionMode } = state;
  const currentStageConfig = gameStages[progress.currentStage - 1];
  
  // 获取普通问题（混合无效、误导、普通）
  const normalQuestions = getAvailableNormalQuestions(progress.answeredQuestions);
  const availableNormalQuestions = normalQuestions.filter(
    q => !progress.answeredQuestions.has(q.id)
  );
  
  const contradictionsFound = progress.recordedContradictions.size;
  const total = progress.discoveredContradictions.size;
  // 通关条件：必须包含湖边线索、清理线索、物证线索
  const hasLakeContradiction = progress.recordedContradictions.has('lake');
  const hasCleanContradiction = progress.recordedContradictions.has('clean');
  const hasEvidenceContradiction = progress.recordedContradictions.has('evidence');
  const canReveal = hasLakeContradiction && hasCleanContradiction && hasEvidenceContradiction;
  const canTryReveal = contradictionsFound > 0;

  return `
    <div class="min-h-screen bg-detective-bg">
      <!-- 顶部状态栏 -->
      <div class="sticky top-0 z-50 bg-gradient-to-r from-gray-800 via-gray-700 to-gray-800 text-gray-50 p-4 shadow-lg border-b-2 border-gray-600">
        <div class="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-4">
          <div class="flex items-center gap-4">
            <div class="flex items-center gap-2">
              <span class="text-2xl">🔍</span>
              <span class="font-serif font-bold text-lg">科伦坡探长</span>
            </div>
            <div class="hidden sm:block text-sm text-amber-200/80">
              第 ${progress.currentStage} 阶段：${currentStageConfig?.name || ''}
            </div>
          </div>
          <div class="flex items-center gap-6">
            <div class="flex items-center gap-2">
              <span>💯</span>
              <span class="font-mono font-bold">${progress.score}</span>
            </div>
            <div class="flex items-center gap-2">
              <span>❌</span>
              <span class="font-mono font-bold">${progress.maxErrors - progress.errors}/${progress.maxErrors}</span>
            </div>
            <div class="flex items-center gap-2">
              <span>❓</span>
              <span class="font-mono font-bold ${progress.questionsAsked >= progress.maxQuestions ? 'text-red-400' : ''}">${progress.maxQuestions - progress.questionsAsked}/${progress.maxQuestions}</span>
            </div>
            <div class="flex items-center gap-2">
              <span>🔎</span>
              <span class="font-mono font-bold">${progress.discoveredContradictions.size}/3</span>
              <span class="text-xs text-amber-200/70">(${contradictionsFound}已记)</span>
            </div>
            <div class="flex items-center gap-2 px-3 py-1 bg-amber-700/50 rounded-full">
              <span>${state.currentStyle === 'gentle' ? '🤝' : state.currentStyle === 'serious' ? '⚡' : '🔍'}</span>
              <span class="text-sm font-bold">${state.currentStyle === 'gentle' ? '温和' : state.currentStyle === 'serious' ? '施压' : '侧击'}</span>
            </div>
          </div>
        </div>
      </div>

      <div class="max-w-7xl mx-auto p-4 md:p-6">
        <div class="grid lg:grid-cols-3 gap-6">
          <!-- 左侧：嫌疑人卡片 -->
          <div class="lg:col-span-2 space-y-4">
            <!-- 嫌疑人信息 -->
            <div class="bg-gray-50/80 rounded-xl p-6 shadow-lg border border-gray-200">
              <div class="flex items-start gap-4">
                <div class="w-20 h-20 rounded-full bg-gradient-to-br from-gray-600 to-gray-800 flex items-center justify-center text-4xl shadow-lg border-2 border-gray-500">
                  🎭
                </div>
                <div class="flex-1">
                  <h2 class="text-xl font-serif font-bold text-gray-900 mb-2">
                    嫌疑人：理查德・卡特
                  </h2>
                  <p class="text-sm text-black/70 mb-2">
                    前CIA特工，海伦的丈夫
                  </p>
                  <div class="flex flex-wrap gap-2">
                    ${progress.discoveredContradictions.has('lake') ? '<span class="px-2 py-1 bg-red-100 text-red-800 text-xs rounded">🏞️ 湖边线索</span>' : ''}
                    ${progress.discoveredContradictions.has('clean') ? '<span class="px-2 py-1 bg-red-100 text-red-800 text-xs rounded">🏠 清理线索</span>' : ''}
                    ${progress.discoveredContradictions.has('evidence') ? '<span class="px-2 py-1 bg-red-100 text-red-800 text-xs rounded">🧬 物证线索</span>' : ''}
                  </div>
                </div>
              </div>
              
              <div class="mt-4 p-3 bg-gray-100/50 rounded-lg border-l-4 border-gray-500">
                <p class="text-sm text-black italic">
                  <span class="font-serif">嫌疑人陈述：</span>
                  "海伦是自己离家出走的，案发当晚我一直在家睡觉，从没去过郊外湖边。"
                </p>
              </div>
            </div>

            <!-- 对话历史 -->
            <div class="bg-amber-50/80 rounded-xl p-4 shadow-lg border border-amber-200 max-h-80 overflow-y-auto">
              <h3 class="font-serif font-bold text-amber-900 mb-3 flex items-center gap-2">
                <span>📜</span> 对话记录
              </h3>
              <div id="conversation-history" class="space-y-3">
                ${progress.conversationHistory.length === 0
                  ? '<p class="text-amber-700/50 text-sm italic text-center py-4">开始提问吧...</p>'
                  : progress.conversationHistory.map(entry => `
                    <div class="flex ${entry.speaker === 'colombo' ? 'justify-end' : entry.speaker === 'suspect' ? 'justify-start' : 'justify-center'}">
                      ${entry.speaker === 'system'
                        ? `<div class="text-xs text-amber-600 bg-amber-100 px-3 py-1 rounded-full">${entry.text}</div>`
                        : `<div class="max-w-[80%] px-4 py-2 rounded-lg ${
                            entry.speaker === 'colombo'
                              ? 'bg-amber-700 text-amber-50'
                              : 'bg-gray-200 text-gray-800'
                          }">
                          <p class="text-sm">${entry.text}</p>
                        </div>`
                      }
                    </div>
                  `).join('')
                }
              </div>
            </div>

            <!-- 提问区域 -->
            <div class="bg-amber-50/80 rounded-xl p-4 shadow-lg border border-amber-200 question-panel">
              <div class="flex items-center justify-between mb-4">
                <h3 class="font-serif font-bold text-amber-900 flex items-center gap-2">
                  <span>❓</span> ${customQuestionMode ? '自由输入' : '你想问什么？'}
                </h3>
                <button id="toggle-mode" class="px-3 py-1 text-sm bg-amber-200 hover:bg-amber-300 text-black rounded transition-colors">
                  ${customQuestionMode ? '📋 菜单选择' : '✏️ 自由输入'}
                </button>
              </div>

              ${customQuestionMode ? `
                <div class="mb-4">
                  <div class="mb-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <p class="text-sm text-amber-800 font-medium mb-2">💬 自由输入模式</p>
                    <p class="text-xs text-amber-700">直接输入你想问的问题，或使用语音输入。尝试问关于：暴雨夜的情况、外套干燥、现场痕迹、餐厅时间、湖边行踪、房屋清理等。</p>
                  </div>
                  <div class="flex gap-2 items-center">
                    <input
                      type="text"
                      id="custom-question"
                      placeholder="例如：昨晚暴雨，你从餐厅出来淋湿了吗？"
                      class="flex-1 px-4 py-3 border-2 border-orange-300 rounded-lg bg-amber-50 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 focus:outline-none text-black font-bold"
                      style="font-family: 'Microsoft YaHei', 'SimHei', sans-serif; letter-spacing: 0.02em;"
                      autocomplete="off"
                      autofocus
                    />
                    <button
                      id="voice-input-btn"
                      class="relative px-3 py-3 bg-orange-200 hover:bg-orange-300 text-black rounded-lg transition-all flex items-center justify-center"
                      title="按住说话或点击开始语音输入"
                    >
                      <svg id="voice-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/>
                        <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                        <line x1="12" x2="12" y1="19" y2="22"/>
                      </svg>
                      <span id="voice-pulse" class="absolute inset-0 rounded-lg bg-red-400 animate-ping opacity-0"></span>
                    </button>
                    <button
                      id="submit-question"
                      class="px-5 py-3 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white rounded-lg transition-all font-bold shadow-md hover:shadow-lg"
                    >
                      <span>发送</span>
                    </button>
                  </div>
                  <div id="voice-status" class="mt-2 text-sm text-center hidden"></div>
                  <div id="custom-feedback" class="mt-2 text-sm text-center hidden"></div>
                  <div class="mt-3 flex flex-wrap gap-2">
                    <span class="text-xs text-amber-700">💡 快速输入：</span>
                    <button class="quick-question text-xs px-2 py-1 bg-amber-100 hover:bg-amber-200 rounded-full border border-amber-300 transition-colors">昨晚暴雨淋湿了吗</button>
                    <button class="quick-question text-xs px-2 py-1 bg-amber-100 hover:bg-amber-200 rounded-full border border-amber-300 transition-colors">餐厅几点停电</button>
                    <button class="quick-question text-xs px-2 py-1 bg-amber-100 hover:bg-amber-200 rounded-full border border-amber-300 transition-colors">现场痕迹</button>
                  </div>
                </div>
              ` : `
                <div class="space-y-2 max-h-60 overflow-y-auto">
                  ${progress.questionsAsked >= progress.maxQuestions
                    ? `<div class="p-4 bg-red-50 border border-red-200 rounded-lg text-center">
                        <p class="text-red-700 font-bold">❌ 已用完所有 ${progress.maxQuestions} 个问题</p>
                        ${!progress.recordedContradictions.has('lake') || !progress.recordedContradictions.has('clean') 
                          ? '<p class="text-sm text-red-600 mt-1">未能收集足够的证据...</p>' 
                          : '<p class="text-sm text-green-600 mt-1">已收集足够证据，可进入结案阶段！</p>'}
                      </div>`
                    : availableNormalQuestions.length === 0
                    ? '<p class="text-amber-700/50 text-sm italic text-center py-4">所有问题都已问过，请使用自由输入深入调查...</p>'
                    : ''
                  }
                  ${shuffleArray(availableNormalQuestions).map(q => `
                    <button
                      class="question-btn w-full text-left px-4 py-3 bg-white hover:bg-amber-100 border border-amber-200 rounded-lg transition-all duration-200 hover:shadow-md ${progress.questionsAsked >= progress.maxQuestions ? 'opacity-50 cursor-not-allowed' : ''}"
                      data-question-id="${q.id}"
                      ${progress.questionsAsked >= progress.maxQuestions ? 'disabled' : ''}
                    >
                      <span class="text-black">→</span> ${q.text}
                    </button>
                  `).join('')}
                </div>
              `}

              <div class="mt-4 p-3 bg-amber-100 border border-amber-300 rounded-lg">
                <p class="text-sm text-amber-900">
                  💡 使用<strong>自由输入</strong>提问，发现关键线索！
                </p>
              </div>

              <div class="mt-4 flex gap-3">
                ${contradictionsFound >= total ? `
                  <button id="final-confrontation" class="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-lg font-bold shadow-lg hover:from-green-700 hover:to-green-800 transition-all animate-pulse">
                    🎉 成功结案！
                  </button>
                ` : canReveal ? `
                  <button id="reveal-truth" class="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-green-700 text-white rounded-lg font-bold shadow-lg hover:from-green-700 hover:to-green-800 transition-all animate-pulse">
                    🏆 揭穿谎言！
                  </button>
                ` : canTryReveal ? `
                  <button id="try-reveal" class="flex-1 px-6 py-3 bg-gradient-to-r from-amber-600 to-amber-700 text-white rounded-lg font-bold shadow-lg hover:from-amber-700 hover:to-amber-800 transition-all">
                    ⚡ 查看记录 (${contradictionsFound}/${total})
                  </button>
                ` : `
                  <button disabled class="flex-1 px-6 py-3 bg-gray-300 text-gray-500 rounded-lg cursor-not-allowed">
                    🔒 需要记录线索
                  </button>
                `}
              </div>
            </div>
          </div>

          <!-- 右侧：线索面板 -->
          <div class="lg:col-span-1">
            <div class="bg-amber-50/80 rounded-xl p-4 shadow-lg border border-amber-200 sticky top-24">
              <h3 class="font-serif font-bold text-amber-900 mb-3 flex items-center justify-between">
                <span class="flex items-center gap-2">
                  <span>📋</span> 线索记录
                </span>
                <span class="text-sm font-normal text-amber-700">${state.progress.clues.length}条</span>
              </h3>

              <div id="clue-list" class="space-y-2 max-h-48 overflow-y-auto mb-3">
                ${state.progress.clues.map(clue => `
                  <div class="flex items-center gap-2 text-xs p-2 bg-amber-100/50 rounded">
                    <span class="w-1.5 h-1.5 rounded-full ${clue.importance === 'critical' ? 'bg-red-500' : clue.importance === 'important' ? 'bg-amber-500' : 'bg-gray-400'}"></span>
                    <span class="text-black">${clue.content}</span>
                  </div>
                `).join('')}
              </div>

              <!-- 已发现待记录线索 -->
              ${state.progress.discoveredContradictions.size > state.progress.recordedContradictions.size ? `
                <div class="border-t border-amber-300 pt-3 mb-3">
                  <h4 class="text-xs font-bold text-red-700 mb-2 flex items-center gap-1">
                    <span>🔍</span> 已发现待记录线索
                  </h4>
                  <div class="space-y-2">
                    ${!state.progress.recordedContradictions.has('lake') && state.progress.discoveredContradictions.has('lake') ? `
                      <div class="p-2 bg-red-50 border border-red-200 rounded text-xs">
                        <p class="text-black mb-1">🏞️ 湖边行踪线索：声称在家却被证人看见在湖边</p>
                        <button onclick="recordContradiction('lake')" class="w-full px-2 py-1 bg-red-600 text-white text-xs rounded hover:bg-red-700">
                          📝 记录此线索
                        </button>
                      </div>
                    ` : ''}
                    ${!state.progress.recordedContradictions.has('clean') && state.progress.discoveredContradictions.has('clean') ? `
                      <div class="p-2 bg-red-50 border border-red-200 rounded text-xs">
                        <p class="text-black mb-1">🏠 清理房屋线索：失踪后立即清洗车库、换地毯</p>
                        <button onclick="recordContradiction('clean')" class="w-full px-2 py-1 bg-red-600 text-white text-xs rounded hover:bg-red-700">
                          📝 记录此线索
                        </button>
                      </div>
                    ` : ''}
                    ${!state.progress.recordedContradictions.has('evidence') && state.progress.discoveredContradictions.has('evidence') ? `
                      <div class="p-2 bg-red-50 border border-red-200 rounded text-xs">
                        <p class="text-black mb-1">🧬 物证线索：湖边找到人体组织与血迹</p>
                        <button onclick="recordContradiction('evidence')" class="w-full px-2 py-1 bg-red-600 text-white text-xs rounded hover:bg-red-700">
                          📝 记录此线索
                        </button>
                      </div>
                    ` : ''}
                  </div>
                </div>
              ` : ''}

              <div class="border-t border-amber-300 pt-3">
                <label class="text-xs text-amber-700 mb-1 block">添加线索</label>
                <div class="flex gap-2">
                  <input
                    type="text"
                    id="new-clue"
                    placeholder="记录重要发现..."
                    class="flex-1 px-2 py-1.5 text-sm border border-amber-300 rounded bg-white focus:border-amber-500 focus:outline-none"
                  />
                  <button id="add-clue" class="px-3 py-1.5 bg-amber-600 text-white text-sm rounded hover:bg-amber-700 transition-colors">
                    +
                  </button>
                </div>
              </div>

              <div class="mt-4 p-3 bg-amber-100/50 rounded-lg">
                <h4 class="text-xs font-bold text-black mb-2">🎬 案件梗概</h4>
                <p class="text-xs text-amber-700 leading-relaxed">
                  知名画家艾伦・索恩报案称价值80万美元的代表作《雾中港湾》失窃。
                  案发当晚暴雨倾盆，画廊后门玻璃被砸，现场无指纹脚印。
                  警方初步判定为流窜盗窃，但唯一的嫌疑人就是报案人本人。
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}

function renderReveal(): string {
  // 第二关通关条件：只需要湖边线索和清理线索
  const hasLake = state.progress.recordedContradictions.has('lake');
  const hasClean = state.progress.recordedContradictions.has('clean');
  const canClose = hasLake && hasClean;
  
  return `
    <div class="min-h-screen bg-detective-bg flex items-center justify-center p-4">
      <div class="max-w-2xl w-full">
        <div class="bg-amber-50/80 rounded-xl p-8 shadow-xl border border-amber-200 text-center">
          <div class="text-6xl mb-6">🎭</div>
          <h2 class="text-2xl font-serif font-bold text-amber-900 mb-4">
            真相时刻
          </h2>
          <p class="text-black mb-6">
            您已记录 ${state.progress.recordedContradictions.size} 个关键线索，现在可以选择揭穿嫌疑人。
          </p>
          
          <div class="grid gap-4 mb-8">
            ${hasLake ? `
              <div class="p-4 bg-green-50 border border-green-200 rounded-lg text-left">
                <h4 class="font-bold text-green-800 mb-1">🏞️ 线索一：湖边行踪</h4>
                <p class="text-sm text-green-700">声称整晚在家，却被证人看见在湖边</p>
              </div>
            ` : `
              <div class="p-4 bg-gray-100 border border-gray-300 rounded-lg text-left opacity-60">
                <h4 class="font-bold text-gray-500 mb-1">🏞️ 线索一：湖边行踪</h4>
                <p class="text-sm text-gray-400">（未记录）</p>
              </div>
            `}
            ${hasClean ? `
              <div class="p-4 bg-green-50 border border-green-200 rounded-lg text-left">
                <h4 class="font-bold text-green-800 mb-1">🏠 线索二：清理房屋</h4>
                <p class="text-sm text-green-700">失踪后立即清洗车库、换地毯</p>
              </div>
            ` : `
              <div class="p-4 bg-gray-100 border border-gray-300 rounded-lg text-left opacity-60">
                <h4 class="font-bold text-gray-500 mb-1">🏠 线索二：清理房屋</h4>
                <p class="text-sm text-gray-400">（未记录）</p>
              </div>
            `}
          </div>

          ${canClose ? `
            <button id="final-confrontation" class="w-full px-6 py-4 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-lg font-bold shadow-lg hover:from-red-700 hover:to-red-800 transition-all text-lg animate-pulse">
              🔍 揭穿真相
            </button>
          ` : `
            <div class="p-4 bg-amber-100 rounded-lg">
              <p class="text-sm text-black">
                ⚠️ 还需要 ${!hasLake && !hasClean ? '2个' : '1个'} 关键线索才能揭穿真相。
              </p>
              <button onclick="state.phase = 'investigation'; renderApp();" class="mt-3 w-full px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700">
                ← 返回调查
              </button>
            </div>
          `}
        </div>
      </div>
    </div>
  `;
}

function renderVictory(): string {
  const cluesFound = state.progress.clues.length - initialClues.length;
  const questionsAsked = state.progress.answeredQuestions.size;
  const currentLevel = getLevel(state.currentLevelId);
  const isLevel2 = currentLevel?.suspectName === '理查德';

  return `
    <div class="min-h-screen bg-detective-bg flex items-center justify-center p-4">
      <div class="max-w-2xl w-full">
        <div class="bg-amber-50/80 rounded-xl p-8 shadow-xl border border-amber-200 text-center">
          <div class="text-6xl mb-6">🏆</div>
          <h2 class="text-3xl font-serif font-bold text-amber-900 mb-4">
            成功结案！
          </h2>
          <p class="text-xl text-black mb-8">
            ${currentLevel?.suspectName || '嫌疑人'} ${isLevel2 ? '承认了杀害海伦、用碎木机毁灭证据的罪行。' : '承认了伪造盗窃现场、骗取保险的罪行。'}
          </p>
          
          <div class="bg-amber-100/50 rounded-lg p-4 mb-8 text-left">
            <h3 class="font-serif font-bold text-amber-900 mb-2">📜 案件真相</h3>
            <p class="text-sm text-black leading-relaxed">
              ${isLevel2 
                ? '理查德因家庭线索和对海伦不满，趁深夜将海伦杀害后用碎木机毁灭证据，抛尸湖中，并清理了家中所有痕迹。他的谎言被彻底揭穿。'
                : '嫌疑人因债务危机急需资金。案发当晚他就回到画廊，自导自演砸碎后门、伪造盗窃现场。他的谎言被彻底揭穿。'}
            </p>
          </div>

          <div class="grid grid-cols-3 gap-4 mb-8">
            <div class="p-4 bg-amber-100 rounded-lg">
              <div class="text-2xl font-bold text-amber-900">${state.progress.score}</div>
              <div class="text-xs text-amber-700">最终得分</div>
            </div>
            <div class="p-4 bg-amber-100 rounded-lg">
              <div class="text-2xl font-bold text-amber-900">${questionsAsked}</div>
              <div class="text-xs text-amber-700">提问次数</div>
            </div>
            <div class="p-4 bg-amber-100 rounded-lg">
              <div class="text-2xl font-bold text-amber-900">${cluesFound}</div>
              <div class="text-xs text-amber-700">自记录线索</div>
            </div>
          </div>

          <button id="play-again" class="px-8 py-3 bg-gradient-to-r from-amber-700 to-amber-800 text-amber-50 rounded-lg font-bold shadow-lg hover:from-amber-800 hover:to-amber-900 transition-all">
            🔄 再玩一次
          </button>
        </div>
      </div>
    </div>
  `;
}

function renderFailure(): string {
  const hasLake = state.progress.recordedContradictions.has('lake');
  const hasClean = state.progress.recordedContradictions.has('clean');
  const questionsExhausted = state.progress.questionsAsked >= state.progress.maxQuestions && 
                             !(hasLake && hasClean);
  
  return `
    <div class="min-h-screen bg-detective-bg flex items-center justify-center p-4">
      <div class="max-w-2xl w-full">
        <div class="bg-amber-50/80 rounded-xl p-8 shadow-xl border border-amber-200 text-center">
          <div class="text-6xl mb-6">😔</div>
          <h2 class="text-3xl font-serif font-bold text-amber-900 mb-4">
            ${questionsExhausted ? '结案失败' : '调查失败'}
          </h2>
          <p class="text-black mb-6">
            ${questionsExhausted
              ? `您已经问完了所有 ${state.progress.maxQuestions} 个问题，但未能收集到足够的证据。理查德最终被无罪释放...`
              : (state.progress.errors >= state.progress.maxErrors
                ? '您消耗了太多机会，嫌疑人逃脱了法律的制裁。'
                : '您的分数耗尽了，需要更加谨慎地进行调查。')}
          </p>
          
          <div class="bg-red-100/50 rounded-lg p-4 mb-8 text-left">
            <h3 class="font-serif font-bold text-red-900 mb-2">📋 调查总结</h3>
            <div class="space-y-2 text-sm text-red-800">
              <p>• 询问问题：${state.progress.questionsAsked}/${state.progress.maxQuestions}</p>
              <p>• 收集线索：${state.progress.recordedContradictions.size}/2</p>
              <p>• 最终得分：${state.progress.score}</p>
              ${!questionsExhausted ? `<p>• 错误次数：${state.progress.errors}/${state.progress.maxErrors}</p>` : ''}
            </div>
          </div>

          <div class="grid gap-3 mb-8">
            ${!state.progress.recordedContradictions.has('lake') ? `
              <div class="p-3 bg-amber-100 rounded-lg text-left">
                <p class="text-sm text-black font-bold">💡 提示：有人看见他深夜在湖边...</p>
              </div>
            ` : ''}
            ${!state.progress.recordedContradictions.has('clean') ? `
              <div class="p-3 bg-amber-100 rounded-lg text-left">
                <p class="text-sm text-black font-bold">💡 提示：为什么失踪后要清洗车库、换地毯？</p>
              </div>
            ` : ''}
          </div>

          <button id="try-again" class="px-8 py-3 bg-gradient-to-r from-amber-700 to-amber-800 text-amber-50 rounded-lg font-bold shadow-lg hover:from-amber-800 hover:to-amber-900 transition-all">
            🔄 重新调查
          </button>
        </div>
      </div>
    </div>
  `;
}

// ============ 事件处理 ============
function attachEventListeners(): void {
  // 选择关卡
  const selectLevelBtn = $('#select-level');
  if (selectLevelBtn) {
    selectLevelBtn.addEventListener('click', () => {
      state.phase = 'level-select';
      renderApp();
    });
  }

  // 快速开始（跳转到第二关）
  const startBtn = $('#start-game');
  if (startBtn) {
    startBtn.addEventListener('click', () => {
      state.currentLevelId = 2; // 默认第二关
      state.progress.maxQuestions = 4;
      resetGameState();
      state.phase = 'rules';
      renderApp();
    });
  }

  // 查看规则后选择审问风格
  const startStyleSelectBtn = $('#start-style-select');
  if (startStyleSelectBtn) {
    startStyleSelectBtn.addEventListener('click', () => {
      state.phase = 'style-select';
      renderApp();
    });
  }

  // 温和套话风格
  const styleGentleBtn = $('#style-gentle');
  if (styleGentleBtn) {
    styleGentleBtn.addEventListener('click', () => {
      state.currentStyle = 'gentle';
      state.phase = 'tutorial';
      state.tutorialIndex = 0;
      renderApp();
    });
  }

  // 严肃施压风格
  const styleSternBtn = $('#style-stern');
  if (styleSternBtn) {
    styleSternBtn.addEventListener('click', () => {
      state.currentStyle = 'serious';
      state.phase = 'tutorial';
      state.tutorialIndex = 0;
      renderApp();
    });
  }

  // 旁敲侧击风格
  const styleIndirectBtn = $('#style-indirect');
  if (styleIndirectBtn) {
    styleIndirectBtn.addEventListener('click', () => {
      state.currentStyle = 'probing';
      state.phase = 'tutorial';
      state.tutorialIndex = 0;
      renderApp();
    });
  }

  // 教程对话框下一步
  const nextDialogueBtn = $('#next-dialogue');
  if (nextDialogueBtn) {
    nextDialogueBtn.addEventListener('click', () => {
      if (state.tutorialIndex < tutorialDialogue.length - 1) {
        state.tutorialIndex++;
        renderApp();
        // 滚动到底部
        setTimeout(() => {
          const container = $('#conversation-history');
          if (container) {
            container.scrollTop = container.scrollHeight;
          }
        }, 50);
      } else {
        // 教程结束，进入调查阶段
        state.phase = 'investigation';
        state.progress.conversationHistory = [];
        // 开始播放背景音乐
        audioManager.playBGM();
        addConversation('system', '审讯开始...');
        renderApp();
      }
    });
  }

  // 切换提问模式
  const toggleModeBtn = $('#toggle-mode');
  if (toggleModeBtn) {
    toggleModeBtn.addEventListener('click', () => {
      state.customQuestionMode = !state.customQuestionMode;
      renderApp();
    });
  }

  // 菜单问题点击
  document.querySelectorAll('.question-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const questionId = (btn as HTMLElement).dataset.questionId;
      if (questionId) {
        handleMenuQuestion(questionId);
      }
    });
  });

  // 关键问题点击
  const keyQuestionBtn = $('#ask-key-question');
  if (keyQuestionBtn) {
    keyQuestionBtn.addEventListener('click', () => {
      handleKeyQuestion();
    });
  }

  // 自由输入问题
  const customInput = $('#custom-question') as HTMLInputElement;
  if (customInput) {
    customInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        handleCustomQuestion(customInput.value);
      }
    });
  }

  // 发送问题按钮
  const submitBtn = $('#submit-question');
  if (submitBtn) {
    submitBtn.addEventListener('click', () => {
      const customInputEl = $('#custom-question') as HTMLInputElement;
      if (customInputEl && customInputEl.value.trim()) {
        handleCustomQuestion(customInputEl.value);
      }
    });
  }

  // 语音输入功能
  const voiceBtn = $('#voice-input-btn');
  if (voiceBtn) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let recognition: any = null;
    let isListening = false;

    // 检测浏览器是否支持语音识别
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'zh-CN';

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        const customInputEl = $('#custom-question') as HTMLInputElement;
        if (customInputEl) {
          customInputEl.value = transcript;
          customInputEl.focus();
        }
        const voiceStatus = $('#voice-status');
        if (voiceStatus) {
          voiceStatus.textContent = `✓ 已识别：${transcript}`;
          voiceStatus.className = 'mt-2 text-sm text-green-600 font-medium';
          voiceStatus.classList.remove('hidden');
        }
        stopListening();
        
        // 自动提交
        setTimeout(() => {
          if (transcript.trim()) {
            handleCustomQuestion(transcript);
            const customInputEl = $('#custom-question') as HTMLInputElement;
            if (customInputEl) customInputEl.value = '';
          }
        }, 500);
      };

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recognition.onerror = (event: any) => {
        console.log('语音识别错误:', event.error);
        const voiceStatus = $('#voice-status');
        if (voiceStatus) {
          let errorMsg = '语音识别出错，请重试';
          if (event.error === 'not-allowed') {
            errorMsg = '请允许使用麦克风权限';
          } else if (event.error === 'no-speech') {
            errorMsg = '未检测到语音，请重试';
          } else if (event.error === 'network') {
            errorMsg = '网络错误，请检查网络连接';
          }
          voiceStatus.textContent = errorMsg;
          voiceStatus.className = 'mt-2 text-sm text-red-500 font-medium';
          voiceStatus.classList.remove('hidden');
        }
        stopListening();
      };

      recognition.onend = () => {
        stopListening();
      };

      const startListening = () => {
        if (recognition && !isListening) {
          try {
            recognition.start();
            isListening = true;
            
            // 更新按钮状态
            voiceBtn.classList.remove('bg-orange-200', 'hover:bg-orange-300');
            voiceBtn.classList.add('bg-red-500', 'hover:bg-red-600');
            voiceBtn.style.transform = 'scale(1.1)';
            
            const voiceIcon = $('#voice-icon');
            if (voiceIcon) {
              voiceIcon.style.color = 'white';
              voiceIcon.innerHTML = `
                <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/>
                <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                <line x1="12" x2="12" y1="19" y2="22"/>
              `;
            }
            
            // 显示录音动画
            const voicePulse = $('#voice-pulse');
            if (voicePulse) {
              voicePulse.classList.remove('opacity-0');
              voicePulse.classList.add('opacity-50');
            }
            
            const voiceStatus = $('#voice-status');
            if (voiceStatus) {
              voiceStatus.textContent = '🎤 正在聆听... 请说话';
              voiceStatus.className = 'mt-2 text-sm text-red-500 font-medium animate-pulse';
              voiceStatus.classList.remove('hidden');
            }
          } catch (err) {
            console.log('启动语音识别失败:', err);
          }
        }
      };

      const stopListening = () => {
        if (recognition && isListening) {
          try {
            recognition.stop();
          } catch {
            // 忽略停止时的错误
          }
          isListening = false;
          
          // 恢复按钮状态
          voiceBtn.classList.remove('bg-red-500', 'hover:bg-red-600');
          voiceBtn.classList.add('bg-orange-200', 'hover:bg-orange-300');
          voiceBtn.style.transform = 'scale(1)';
          
          const voiceIcon = $('#voice-icon');
          if (voiceIcon) {
            voiceIcon.style.color = 'black';
            voiceIcon.innerHTML = `
              <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/>
              <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
              <line x1="12" x2="12" y1="19" y2="22"/>
            `;
          }
          
          // 隐藏录音动画
          const voicePulse = $('#voice-pulse');
          if (voicePulse) {
            voicePulse.classList.add('opacity-0');
            voicePulse.classList.remove('opacity-50');
          }
        }
      };

      voiceBtn.addEventListener('click', () => {
        if (isListening) {
          stopListening();
        } else {
          startListening();
        }
      });
    } else {
      // 浏览器不支持语音识别
      voiceBtn.addEventListener('click', () => {
        const voiceStatus = $('#voice-status');
        if (voiceStatus) {
          voiceStatus.innerHTML = '<span>❌ 浏览器不支持语音识别</span><br><span class="text-xs">请使用Chrome浏览器或手动输入问题</span>';
          voiceStatus.className = 'mt-2 text-sm text-red-500 text-center';
          voiceStatus.classList.remove('hidden');
        }
      });
    }
  }
  
  // 快速输入按钮
  const quickQuestionBtns = document.querySelectorAll('.quick-question');
  quickQuestionBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const customInputEl = $('#custom-question') as HTMLInputElement;
      if (customInputEl) {
        customInputEl.value = btn.textContent || '';
        customInputEl.focus();
      }
    });
  });
  
  // 发送按钮悬停效果
  const submitBtnHover = $('#submit-question');
  if (submitBtnHover) {
    submitBtnHover.addEventListener('mouseenter', () => {
      submitBtnHover.style.transform = 'scale(1.05)';
    });
    submitBtnHover.addEventListener('mouseleave', () => {
      submitBtnHover.style.transform = 'scale(1)';
    });
  }

  // 添加线索
  const addClueBtn = $('#add-clue');
  const newClueInput = $('#new-clue') as HTMLInputElement;
  if (addClueBtn && newClueInput) {
    addClueBtn.addEventListener('click', () => {
      if (newClueInput.value.trim()) {
        state.progress.clues.push({
          id: `clue-${Date.now()}`,
          content: newClueInput.value.trim(),
          category: 'observation',
          importance: 'important',
        });
        newClueInput.value = '';
        renderApp();
      }
    });
  }

  // 揭穿按钮
  const revealBtn = $('#reveal-truth');
  if (revealBtn) {
    revealBtn.addEventListener('click', () => {
      state.phase = 'reveal';
      renderApp();
    });
  }

  // 尝试揭穿按钮 - 改为查看记录
  const tryRevealBtn = $('#try-reveal');
  if (tryRevealBtn) {
    tryRevealBtn.addEventListener('click', () => {
      // 显示当前已记录和待记录的线索
      const recorded = state.progress.recordedContradictions.size;
      const total = state.progress.discoveredContradictions.size;
      
      if (recorded >= total) {
        // 所有线索都已记录，直接跳转到通关
        audioManager.playVictorySound();
        audioManager.pauseBGM();
        state.phase = 'victory';
      } else {
        state.phase = 'reveal';
      }
      renderApp();
    });
  }

  // 最终对峙
  const finalBtn = $('#final-confrontation');
  if (finalBtn) {
    finalBtn.addEventListener('click', () => {
      // 播放通关成功音效
      audioManager.playVictorySound();
      // 暂停背景音乐
      audioManager.pauseBGM();
      state.phase = 'victory';
      renderApp();
    });
  }

  // 重新开始
  const playAgainBtn = $('#play-again');
  const tryAgainBtn = $('#try-again');
  if (playAgainBtn) {
    playAgainBtn.addEventListener('click', resetGame);
  }
  if (tryAgainBtn) {
    tryAgainBtn.addEventListener('click', resetGame);
  }
}

function addConversation(
  speaker: 'colombo' | 'suspect' | 'system',
  text: string,
  autoScroll: boolean = true
): void {
  state.progress.conversationHistory.push({ speaker, text });
  if (autoScroll) {
    updateConversationArea();
  }
}

// 更新对话区域（仅更新对话列表，不重新渲染整个页面）
function updateConversationArea(): void {
  const conversationDiv = document.getElementById('conversation-history');
  if (!conversationDiv) return;
  
  const { conversationHistory } = state.progress;
  if (conversationHistory.length === 0) {
    conversationDiv.innerHTML = '<p class="text-amber-700/50 text-sm italic text-center py-4">开始提问吧...</p>';
  } else {
    conversationDiv.innerHTML = conversationHistory.map(entry => `
      <div class="flex ${entry.speaker === 'colombo' ? 'justify-end' : entry.speaker === 'suspect' ? 'justify-start' : 'justify-center'}">
        ${entry.speaker === 'system'
          ? `<div class="text-xs text-amber-600 bg-amber-100 px-3 py-1 rounded-full">${entry.text}</div>`
          : `<div class="max-w-[80%] px-4 py-2 rounded-lg ${
              entry.speaker === 'colombo'
                ? 'bg-amber-700 text-amber-50'
                : 'bg-gray-200 text-gray-800'
            }">
            <p class="text-sm">${entry.text}</p>
          </div>`
        }
      </div>
    `).join('');
  }
  
  // 自动滚动到底部（使用 requestAnimationFrame 确保 DOM 更新完成）
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      conversationDiv.scrollTop = conversationDiv.scrollHeight;
    });
  });
}

// 处理菜单选择问题
function handleMenuQuestion(questionId: string): void {
  const question = questions.find(q => q.id === questionId);
  if (!question || state.progress.answeredQuestions.has(questionId)) return;

  // 检查是否还有问题可用
  if (state.progress.questionsAsked >= state.progress.maxQuestions) {
    return; // 已用完所有问题
  }

  // 增加问题计数
  state.progress.questionsAsked++;

  // 顺序关键问题不再需要按顺序回答，直接处理
  // 记录已回答
  state.progress.answeredQuestions.add(questionId);

  // 科伦坡提问
  addConversation('colombo', question.text);

  // 获取嫌疑人回答（使用轮换的回答，根据风格）
  const responseCount = state.progress.topicResponses.get(question.id) || 0;
  state.progress.topicResponses.set(question.id, responseCount + 1);

  const { response, followUp, attitude } = getStyledSuspectResponse(question, responseCount, state.currentStyle);
  addConversation('suspect', attitude + response);

  // 科伦坡跟进
  setTimeout(() => {
    addConversation('colombo', followUp);

    // 根据问题类型处理
    if (question.type === 'invalid') {
      // 无效问题：不得分，不推进进度
      addConversation('system', `❓ 这个问题似乎和案件无关...`);
    } else if (question.type === 'misleading') {
      // 误导性问题：得少量分，但不发现线索
      state.progress.score += question.basePoints;
      addConversation('system', `+${question.basePoints}分（但似乎没有发现关键线索）`);
      state.stageAnsweredCount++;
    } else if (question.type === 'sequential-key') {
      // 顺序关键问题 - 设置对应的问题询问标志
      if (question.contradictionId === 'lake') {
        state.askedTimeQuestion = true;
      } else if (question.contradictionId === 'clean') {
        state.askedRainQuestion = true;
      } else if (question.contradictionId === 'evidence') {
        state.askedTraceQuestion = true;
      }
      
      if (question.contradictionId) {
        state.progress.discoveredContradictions.add(question.contradictionId);
        state.progress.score += question.basePoints;
        addConversation('system', `🔍 发现线索：${getContradictionName(question.contradictionId)}！+${question.basePoints}分`);

        // 添加线索
        addKeyClue(question.contradictionId);
        
        // 不再推进顺序索引，让玩家可以自由探索
        state.stageAnsweredCount = 0;
      }
    } else if (question.type === 'hidden-key') {
      // 隐藏关键问题 - 设置已询问关键问题的标志
      state.askedHiddenKeyQuestion = true;
      // 这个问题不在菜单中，但保留逻辑
      state.progress.score += question.basePoints;
      addConversation('system', `+${question.basePoints}分`);
    } else {
      // 普通问题
      state.progress.score += question.basePoints;
      addConversation('system', `+${question.basePoints}分`);
      state.stageAnsweredCount++;
    }

    // 检查是否需要进入下一阶段
    checkStageProgression();

    // 检查游戏结束条件
    if (state.progress.errors >= state.progress.maxErrors || state.progress.score <= 0) {
      state.phase = 'failure';
    }

    // 检查是否用完所有问题且未收集足够线索（第二关需要lake和clean）
    if (state.progress.questionsAsked >= state.progress.maxQuestions) {
      const hasLake = state.progress.recordedContradictions.has('lake');
      const hasClean = state.progress.recordedContradictions.has('clean');
      if (!(hasLake && hasClean)) {
        state.phase = 'failure';
      }
    }

    renderApp();
  }, 800);
}

// 处理关键问题
function handleKeyQuestion(): void {
  state.customQuestionMode = true;
  renderApp();

  const input = $('#custom-question') as HTMLInputElement;
  if (input) {
    input.focus();
  }
}

// 处理自由输入
function handleCustomQuestion(input: string): void {
  if (!input.trim()) return;

  // 简化匹配逻辑 - 检查是否匹配任意一个顺序关键问题
  let matchedQuestion: QuestionVariant | null = null;
  
  for (const sq of sequentialKeyQuestions) {
    if (sq.keywords) {
      const { matched: isMatched } = checkKeyQuestionMatch(input, sq.keywords);
      if (isMatched) {
        matchedQuestion = sq;
        break;
      }
    }
  }

  if (matchedQuestion) {
    if (state.progress.answeredQuestions.has(matchedQuestion.id)) {
      // 已经回答过
      addConversation('colombo', input);
      addConversation('suspect', '我刚才已经回答过这个问题了。');
      addConversation('system', '这个问题你已经问过了，换一个吧。');
      renderApp();
      return;
    }

    state.progress.answeredQuestions.add(matchedQuestion.id);

    // 科伦坡提问
    addConversation('colombo', matchedQuestion.text);

    // 嫌疑人回答（根据风格）
    const responseCount = state.progress.topicResponses.get(matchedQuestion.id) || 0;
    state.progress.topicResponses.set(matchedQuestion.id, responseCount + 1);

    const { response, followUp, attitude } = getStyledSuspectResponse(matchedQuestion, responseCount, state.currentStyle);
    addConversation('suspect', attitude + response);

    // 设置对应的问题询问标志
    if (matchedQuestion.contradictionId === 'rain') {
      state.askedRainQuestion = true;
    } else if (matchedQuestion.contradictionId === 'dust') {
      state.askedTraceQuestion = true;
    } else if (matchedQuestion.contradictionId === 'electricity') {
      state.askedTimeQuestion = true;
    }

    // 科伦坡跟进
    setTimeout(() => {
      addConversation('colombo', followUp);

      if (matchedQuestion!.contradictionId) {
        // 发现线索！检查是否已记录
        if (state.progress.recordedContradictions.has(matchedQuestion!.contradictionId)) {
          // 已记录过
          state.progress.score += matchedQuestion!.basePoints;
          addConversation('system', `✓ 已记录的线索发挥作用！+${matchedQuestion!.basePoints}分`);
        } else {
          // 发现新线索！需要玩家记录
          state.progress.discoveredContradictions.add(matchedQuestion!.contradictionId);
          addConversation('system', `🔍 发现重要线索！请在下方"已发现线索"区域点击记录此线索！`);
          addConversation('system', `📋 ${getContradictionDescription(matchedQuestion!.contradictionId)}`);
        }
        
        // 不再推进顺序索引
        state.stageAnsweredCount = 0;
      }

      checkStageProgression();

      if (state.progress.errors >= state.progress.maxErrors || state.progress.score <= 0) {
        state.phase = 'failure';
      }

      state.customQuestionMode = false;
      renderApp();
    }, 800);
  } else {
    // 没有匹配任何关键问题 - 给玩家提示
    addConversation('colombo', input);
    addConversation('suspect', '这...这个话题我不清楚。您为什么不问问我那天晚上的具体情况呢？');
    addConversation('system', `💡 提示：尝试问一些关于嫌疑人陈述中的细节，比如暴雨夜的情况、外套、现场痕迹、餐厅时间等。`);

    renderApp();
  }
}

function getContradictionName(id: string): string {
  const names: Record<string, string> = {
    rain: '暴雨夜的线索',
    dust: '画材粉尘线索',
    electricity: '餐厅停电线索',
  };
  return names[id] || '未知线索';
}

function getContradictionDescription(id: string): string {
  const descriptions: Record<string, string> = {
    rain: '暴雨夜未撑伞，外套却完全干燥，与"全程在室外行走"线索',
    dust: '声称未进入失窃现场，却在碎玻璃上留下专属画材粉尘',
    electricity: '声称19-21点在餐厅用餐，而该餐厅当晚19:45已停电',
  };
  return descriptions[id] || '未知线索描述';
}

// 记录线索功能
function recordContradiction(contradictionId: string): void {
  state.progress.recordedContradictions.add(contradictionId);
  state.progress.score += 15; // 记录线索奖励15分
  
  // 添加到线索列表
  const clueContents: Record<string, { content: string; category: 'physical' | 'testimony' | 'alibi' | 'observation'; importance: 'critical' | 'important' | 'minor' }> = {
    lake: { content: '深夜出现在湖边使用碎木机，与"在家睡觉"证词线索', category: 'testimony', importance: 'critical' },
    clean: { content: '妻子失踪后立刻清洗车库、更换地毯，意图销毁证据', category: 'observation', importance: 'critical' },
    evidence: { content: '湖边找到海伦的人体组织与血迹，与碎木机痕迹吻合', category: 'physical', importance: 'critical' },
  };
  
  const clue = clueContents[contradictionId];
  if (clue) {
    state.progress.clues.push({
      id: `recorded-${contradictionId}`,
      ...clue,
    });
  }

  // 播放发现线索音效
  audioManager.playClueFoundSound();

  addConversation('system', `✅ 线索已记录！+15分`);
  renderApp();
}

function addKeyClue(contradictionId: string): void {
  const clueContents: Record<string, { content: string; category: 'physical' | 'testimony' | 'alibi' | 'observation'; importance: 'critical' | 'important' | 'minor' }> = {
    lake: { content: '深夜出现在湖边使用碎木机，与"在家睡觉"证词线索', category: 'testimony', importance: 'critical' },
    clean: { content: '妻子失踪后立刻清洗车库、更换地毯，意图销毁证据', category: 'observation', importance: 'critical' },
    evidence: { content: '湖边找到海伦的人体组织与血迹，与碎木机痕迹吻合', category: 'physical', importance: 'critical' },
  };

  const clue = clueContents[contradictionId];
  if (clue) {
    state.progress.clues.push({
      id: `clue-${Date.now()}`,
      ...clue,
    });
  }
}

function checkStageProgression(): void {
  const currentStageConfig = gameStages[state.progress.currentStage - 1];
  if (!currentStageConfig) return;

  // 检查是否已经完成了当前的顺序关键问题
  const currentSeqQuestion = getCurrentSequentialKeyQuestion(state.progress.currentSequentialIndex);
  const isSeqCompleted = currentSeqQuestion 
    ? state.progress.answeredQuestions.has(currentSeqQuestion.id)
    : true;

  // 如果当前顺序关键问题未完成，不进入下一阶段
  if (!isSeqCompleted && state.progress.currentSequentialIndex < 4) {
    return;
  }

  // 检查是否满足进入下一阶段的条件
  if (state.stageAnsweredCount >= currentStageConfig.requiredQuestions) {
    // 如果是关键对峙阶段（阶段4），不需要再解锁新问题
    if (state.progress.currentStage === 4) {
      return;
    }
    
    if (state.progress.currentStage < gameStages.length) {
      const nextStage = state.progress.currentStage + 1;
      const nextStageConfig = gameStages[nextStage - 1];
      
      // 检查下一个阶段是否需要新的顺序关键问题
      if (nextStageConfig.unlocksSequentialKey && nextStageConfig.sequentialOrder) {
        // 确保下一个关键问题还没有被回答
        const nextSeqQuestion = sequentialKeyQuestions.find(
          (q: QuestionVariant) => q.sequentialOrder === nextStageConfig.sequentialOrder
        );
        if (nextSeqQuestion && !state.progress.answeredQuestions.has(nextSeqQuestion.id)) {
          state.progress.currentStage++;
          state.stageAnsweredCount = 0;
          addConversation('system', `📍 进入第 ${state.progress.currentStage} 阶段：${gameStages[state.progress.currentStage - 1].name}`);
          return;
        }
      }
      
      // 普通阶段推进
      state.progress.currentStage++;
      state.stageAnsweredCount = 0;
      addConversation('system', `📍 进入第 ${state.progress.currentStage} 阶段：${gameStages[state.progress.currentStage - 1].name}`);
    }
  }
}

function resetGame(): void {
  state.phase = 'intro';
  state.progress = {
    score: 100,
    errors: 0,
    maxErrors: 3,
    currentStage: 1,
    currentSequentialIndex: 1,
    answeredQuestions: new Set(),
    questionsAsked: 0, // 重置问题计数
    maxQuestions: 5, // 最大问题数
    discoveredContradictions: new Set(),
    recordedContradictions: new Set<string>(), // 重置已记录线索
    conversationHistory: [],
    clues: [...initialClues],
    topicResponses: new Map(),
  };
  state.customQuestionMode = false;
  state.selectedQuestionId = null;
  state.stageAnsweredCount = 0;
  state.currentStyle = 'gentle'; // 重置审问风格
  state.tutorialIndex = 0; // 重置教程索引
  state.askedHiddenKeyQuestion = false; // 重置隐藏关键问题状态
  renderApp();
}

// ============ 全局函数（供 HTML onclick 调用）===========
declare global {
  interface Window {
    recordContradiction: (id: string) => void;
    toggleBGM: () => void;
  }
}

function toggleBGM(): void {
  const isPlaying = audioManager.toggleBGM();
  const icon = document.getElementById('bgm-icon');
  if (icon) {
    if (isPlaying) {
      icon.innerHTML = `
        <path d="M9 18V5l12-2v13"/>
        <circle cx="6" cy="18" r="3"/>
        <circle cx="18" cy="16" r="3"/>
      `;
      icon.classList.remove('text-gray-400');
      icon.classList.add('text-amber-700');
    } else {
      icon.innerHTML = `
        <path d="M9 18V5l12-2v13"/>
        <circle cx="6" cy="18" r="3"/>
        <circle cx="18" cy="16" r="3"/>
        <line x1="23" y1="9" x2="17" y2="15"/>
        <line x1="17" y1="9" x2="23" y2="15"/>
      `;
      icon.classList.remove('text-amber-700');
      icon.classList.add('text-gray-400');
    }
  }
}

// 导出到全局，供 onclick 调用
window.recordContradiction = recordContradiction;
window.toggleBGM = toggleBGM;

// ============ 初始化 ============
function initApp(): void {
  renderApp();
}

// 启动应用
initApp();
